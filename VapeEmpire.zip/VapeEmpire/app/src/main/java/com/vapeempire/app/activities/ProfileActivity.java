package com.vapeempire.app.activities;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.bruce.pickerview.popwindow.DatePickerPopWin;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.squareup.picasso.Picasso;
import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener,
        GoogleApiClient.OnConnectionFailedListener  {

    private Toolbar toolbar;
    private ProfileActivity fthis;
    private SharedPrefManager sharedPrefManager;
    private Button btnlogout, btnUpdate;
    private GoogleApiClient mGoogleApiClient;

    private ImageView img_userpic, img_dob;
    private EditText ed_username, ed_dob, ed_emailid, ed_mobileno;
    private RadioButton rbGender_male, rbGender_female, rbMStatus_married, rbMStatus_single;
    private int gender_stats = -1, mststus_status = -1;
    private String dob = "", updateName, updateEmail, updateMob, updateDob;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        sharedPrefManager = new SharedPrefManager(this);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getProfileActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnlogout = (Button)findViewById(R.id.btnLogout);
        btnlogout.setOnClickListener(this);
        btnUpdate = (Button)findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        rbGender_female = (RadioButton)findViewById(R.id.rbGender_female);
        rbGender_female.setOnClickListener(this);
        rbGender_male = (RadioButton)findViewById(R.id.rbGender_male);
        rbGender_male.setOnClickListener(this);

        rbMStatus_single = (RadioButton)findViewById(R.id.rbMStatus_single);
        rbMStatus_single.setOnClickListener(this);
        rbMStatus_married = (RadioButton)findViewById(R.id.rbMStatus_married);
        rbMStatus_married.setOnClickListener(this);

        ed_username = (EditText)findViewById(R.id.ed_username);
        ed_emailid = (EditText)findViewById(R.id.ed_emailid);
        ed_mobileno = (EditText)findViewById(R.id.ed_mobileno);
        ed_dob = (EditText)findViewById(R.id.ed_dob);
        img_userpic = (ImageView)findViewById(R.id.img_userpic);
        img_dob = (ImageView)findViewById(R.id.img_dob);
        img_dob.setOnClickListener(this);
        ed_username.setText(sharedPrefManager.getUname());

        if(sharedPrefManager.getUpicurl() != null && sharedPrefManager.getUpicurl().length() > 0){
            Picasso.with(fthis).load(sharedPrefManager.getUpicurl()).into(img_userpic);
        }
        if(sharedPrefManager.getEmail() != null && sharedPrefManager.getEmail().length() >0){
            ed_emailid.setText(sharedPrefManager.getEmail().toString());
        }
        if(sharedPrefManager.getPhone_number() != null && sharedPrefManager.getPhone_number().length() >0){
            ed_mobileno.setText(sharedPrefManager.getPhone_number().toString());
        }
        if(sharedPrefManager.getUpicurl() != null && sharedPrefManager.getUpicurl().length() > 0){
            Picasso.with(fthis).load(sharedPrefManager.getUpicurl()).into(img_userpic);
        }else {
            if (sharedPrefManager.getUgender() > 0) {
                if (sharedPrefManager.getUgender() == 1) {
                    gender_stats = 1;
                    rbGender_male.setChecked(true);
                    img_userpic.setImageResource(R.drawable.ic_user_m);
                } else if (sharedPrefManager.getUgender() == 2) {
                    rbGender_female.setChecked(true);
                    gender_stats = 2;
                    img_userpic.setImageResource(R.drawable.ic_user_f);
                }
            }
        }
        if(sharedPrefManager.getUmstatus() > 0){
            if(sharedPrefManager.getUmstatus() == 1){
                mststus_status = 1;
                rbMStatus_single.setChecked(true);
            }else if(sharedPrefManager.getUmstatus() == 2){
                rbMStatus_married.setChecked(true);
                mststus_status = 2;
            }
        }
        if(sharedPrefManager.getUdob().length() > 0){
            ed_dob.setText(Helper.getDob(Integer.parseInt(sharedPrefManager.getUdob().split("-")[2]), Integer.parseInt(sharedPrefManager.getUdob().split("-")[1]), Integer.parseInt(sharedPrefManager.getUdob().split("-")[0])));
            updateDob = sharedPrefManager.getUdob();
        }

    }

    private void googleSignOut() {
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                        sharedPrefManager.logout();
                        LoginManager.getInstance().logOut();
                        startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
                        finishAffinity();
                    }
                });
    }
    private void fbSignOut() {
        sharedPrefManager.logout();
        LoginManager.getInstance().logOut();
        startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
        finishAffinity();
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnLogout:
                confirmDeleteAddress();
                break;
            case R.id.btnUpdate:
                updateProfile();
                break;
            case R.id.img_dob:
                getDate();
                break;
            case R.id.rbGender_female:
                gender_stats = 2;
                break;
            case R.id.rbGender_male:
                gender_stats = 1;
                break;
            case R.id.rbMStatus_married:
                mststus_status = 2;
                break;
            case R.id.rbMStatus_single:
                mststus_status = 1;
                break;
        }
    }
    public void updateProfile(){
        if(ed_username.getText().toString().length() < 6){
            Toast.makeText(getApplicationContext(), "You name must be atleast 6 character long.", Toast.LENGTH_SHORT).show();
        }else if(ed_emailid.getText().toString().length() < 1){
            Toast.makeText(getApplicationContext(), "Please enter your email address.", Toast.LENGTH_SHORT).show();
        }else if(ed_mobileno.getText().toString().length() < 10){
            Toast.makeText(getApplicationContext(), "Please enter your mobile number.", Toast.LENGTH_SHORT).show();
        }else if(gender_stats == -1){
            Toast.makeText(getApplicationContext(), "Please select your gender.", Toast.LENGTH_SHORT).show();
        }else if(mststus_status == -1){
            Toast.makeText(getApplicationContext(), "Please select your maritial status.", Toast.LENGTH_SHORT).show();
        }else if(dob.length() == 0){
            Toast.makeText(getApplicationContext(), "Please select your daye of birth.", Toast.LENGTH_SHORT).show();
        }else{
            updateName = ed_username.getText().toString();
            updateEmail = ed_emailid.getText().toString();
            updateMob = ed_mobileno.getText().toString();
            updateDob = dob;

            netConnection = new NetConnection();
            Map<String, String> networkDetails = netConnection.getConnectionDetails(ProfileActivity.this);
            if(!networkDetails.isEmpty()) {
                new AttemptProfileUpdate().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(ProfileActivity.this), Toast.LENGTH_LONG).show();
            }
        }
    }

    class AttemptProfileUpdate extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProfileActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("acces_token", sharedPrefManager.getUserId());
                objData.put("login_by", sharedPrefManager.getLoginType());
                objData.put("name", updateName);
                objData.put("is_login", true);
                objData.put("email_id", updateEmail);
                objData.put("os", sharedPrefManager.getDeviceOs());
                objData.put("gender", gender_stats+"");
                objData.put("marital_status", mststus_status+"");
                objData.put("phone_number", updateMob);
                objData.put("dob", updateDob);

                json = jsonParser.makeHttpRequestJSON(URLManager.updateProfileURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        JSONObject udata = jsonObject.getJSONObject("data");
                        if(udata.getString("gender").length() > 0) {
                            sharedPrefManager.setUgender(Integer.parseInt(udata.getString("gender")));
                        }
                        sharedPrefManager.setEmail(udata.getString("email_id").toString());
                        sharedPrefManager.setPhone_number(udata.getString("phone_number"));
                        sharedPrefManager.setUdob(udata.getString("dob"));
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "some error occurred. Try again.", Toast.LENGTH_SHORT).show();
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class AttemptLogout extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProfileActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());

                json = jsonParser.makeHttpRequestJSON(URLManager.LogoutURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(sharedPrefManager.getLoginType().equals("google")){
                            googleSignOut();
                        }else if(sharedPrefManager.getLoginType().equals("facebook")){
                            fbSignOut();
                        }else{
                            sharedPrefManager.logout();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "some error occurred. Try again.", Toast.LENGTH_SHORT).show();
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public void getDate(){
        DatePickerPopWin pickerPopWin = new DatePickerPopWin.Builder(ProfileActivity.this, new DatePickerPopWin.OnDatePickedListener() {
            @Override
            public void onDatePickCompleted(int year, int month, int day, String dateDesc) {
                ed_dob.setText(Helper.getDob(year, month, day));
                dob = day+"-"+month+"-"+year;

            }
        }).textConfirm("CONFIRM") //text of confirm button
                .textCancel("CANCEL") //text of cancel button
                .btnTextSize(16) // button text size
                .viewTextSize(25) // pick view text size
                .colorCancel(Color.parseColor("#999999")) //color of cancel button
                .colorConfirm(Color.parseColor("#009900"))//color of confirm button
                .minYear(1907) //min year in loop
                .maxYear(2007) // max year in loop
                .showDayMonthYear(true) // shows like dd mm yyyy (default is false)
                //.dateChose(Helper.getCurrentDate()) // date chose when init popwindow
                .build();
        pickerPopWin.showPopWin(fthis);
    }
    public void signout(){
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(ProfileActivity.this);
        if(!networkDetails.isEmpty()) {
            new AttemptLogout().execute();
        }else{
            //Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(ProfileActivity.this), Toast.LENGTH_LONG).show();
            sharedPrefManager.logout();
        }
    }

    public void confirmDeleteAddress(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure, you want to logout ?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        signout();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(ProfileActivity.this), Toast.LENGTH_LONG).show();
    }
}
