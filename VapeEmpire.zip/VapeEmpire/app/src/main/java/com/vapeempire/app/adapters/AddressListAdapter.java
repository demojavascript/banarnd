package com.vapeempire.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.provider.Telephony;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.vapeempire.app.R;
import com.vapeempire.app.activities.AddressActivity;
import com.vapeempire.app.activities.EditAddressActivity;
import com.vapeempire.app.activities.OrderDetailActivity;
import com.vapeempire.app.models.Address;
import com.vapeempire.app.models.Order;

import java.util.ArrayList;

/**
 * Created by Rahul on 16-08-2016.
 */
public class AddressListAdapter extends RecyclerView.Adapter<AddressListAdapter.OrderListViewHolder> {
    ArrayList<Address> addresses = new ArrayList<Address>();
    Context ctx;
    RecyclerView resourceIdd;
    private String[] state;
    public AddressListAdapter(ArrayList<Address> addresses, Context ctx, RecyclerView resourceIdd){
        this.addresses = addresses;
        this.ctx = ctx;
        this.resourceIdd = resourceIdd;
        Resources objres = ctx.getResources();
        state = objres.getStringArray(R.array.allState);
    }
    @Override
    public OrderListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.address_list_column, parent, false);
        OrderListViewHolder contactViewHolder = new OrderListViewHolder(view, ctx, addresses, resourceIdd);
        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(OrderListViewHolder holder, int position) {
        Address objAddress = addresses.get(position);
        String str_pin = "";
        if(objAddress.getLname().length() > 0) {
            holder.tvName.setText(objAddress.getFname() + " " + objAddress.getLname());
        }
        str_pin = objAddress.getAddress1();
        if(objAddress.getAddress2().length() > 0){
            str_pin = str_pin +", "+ objAddress.getAddress2();
        }
        if(objAddress.getStreet().length() > 0){
            str_pin = str_pin +", "+ objAddress.getStreet();
        }
        holder.tv_address1_street.setText(str_pin);
        holder.tv_pincode_city_state.setText(objAddress.getPincode()+", "+objAddress.getCity());
        holder.tv_country.setText(state[Integer.parseInt(objAddress.getState())]+", "+objAddress.getCountry());
        holder.tv_email.setText(objAddress.getEmailid());
        holder.tv_mobile.setText(objAddress.getMobileno());
    }
    @Override
    public int getItemCount() {
        return addresses.size();
    }
    public static class OrderListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvName, tv_address1_street, tv_pincode_city_state, tv_country, tv_email, tv_mobile;
        CardView cardview_row_order;
        Context ctx;
        ImageView img_edit, img_delete;
        ArrayList<Address> addresses;
        public OrderListViewHolder(View view, Context ctx, ArrayList<Address> addresses, RecyclerView resourceIdd){
            super(view);
            this.addresses = addresses;
            this.ctx = ctx;
            tvName = (TextView)view.findViewById(R.id.tvName);
            tv_address1_street = (TextView)view.findViewById(R.id.tv_address1_street);
            tv_pincode_city_state = (TextView)view.findViewById(R.id.tv_pincode_city_state);
            tv_country = (TextView)view.findViewById(R.id.tv_country);
            tv_email = (TextView)view.findViewById(R.id.tv_email);
            tv_mobile = (TextView)view.findViewById(R.id.tv_mobile);
            cardview_row_order = (CardView)view.findViewById(R.id.cardview_row_order);
            img_edit = (ImageView)view.findViewById(R.id.img_edit);
            img_edit.setOnClickListener(this);
            img_delete = (ImageView)view.findViewById(R.id.img_delete);
            img_delete.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int pos = getAdapterPosition();
            if(v.getId() == R.id.img_edit){
                Intent intent = new Intent(ctx, EditAddressActivity.class);
                intent.putExtra("address", this.addresses.get(pos));
                ctx.startActivity(intent);
            }
            if(v.getId() == R.id.img_delete){
                AddressActivity inst1 = AddressActivity.instance();
                inst1.confirmDeleteAddress(this.addresses.get(pos).getId());
            }
        }
    }
}
