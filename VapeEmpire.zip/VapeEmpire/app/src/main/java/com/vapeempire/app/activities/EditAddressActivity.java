package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Address;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class EditAddressActivity extends AppCompatActivity   implements View.OnClickListener,
        AdapterView.OnItemSelectedListener {

    private Toolbar toolbar;
    private EditAddressActivity fthis;
    private SharedPrefManager sharedPrefManager;
    private Spinner sp_State;
    private String[] state;
    private ArrayAdapter<String> stateAdapter;
    private EditText  ed_address1, ed_address2, ed_fname, ed_lname, ed_street, ed_city, ed_country, ed_pincode,ed_email, ed_contactnum;
    private Button btnUpdate;
    private String str_addressid, str_address1, str_address2, str_fname, str_lname, str_street, str_city, str_state, str_country, str_pincode, str_email, str_contactnum;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonEditAddress;
    private NetConnection netConnection;
    private Address address;
    private int address_type = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_address);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getEditAddressActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Resources objres = getResources();
        state = objres.getStringArray(R.array.allState);
        sp_State = (Spinner)findViewById(R.id.sp_State);
        sp_State.setOnItemSelectedListener(this);
        stateAdapter =  new ArrayAdapter(this,android.R.layout.simple_spinner_item, state);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_State.setAdapter(stateAdapter);

        ed_address1 = (EditText)findViewById(R.id.ed_address1);
        ed_address2 = (EditText)findViewById(R.id.ed_address2);
        ed_fname = (EditText)findViewById(R.id.ed_fname);
        ed_lname = (EditText)findViewById(R.id.ed_lname);
        ed_street = (EditText)findViewById(R.id.ed_street);
        ed_city = (EditText)findViewById(R.id.ed_city);
        ed_country = (EditText)findViewById(R.id.ed_country);
        ed_pincode = (EditText)findViewById(R.id.ed_pincode);
        ed_email = (EditText)findViewById(R.id.ed_email);
        ed_contactnum = (EditText)findViewById(R.id.ed_contactnum);
        btnUpdate = (Button)findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        try{
            Intent intent = getIntent();
            Bundle bundle = intent.getExtras();
            if(!bundle.isEmpty()) {
                address = (Address) intent.getSerializableExtra("address");
                sp_State.setSelection(Integer.parseInt(address.getState()));
                ed_address1.setText(address.getAddress1());
                ed_address2.setText(address.getAddress2());
                ed_fname.setText(address.getFname());
                ed_lname.setText(address.getLname());
                ed_street.setText(address.getStreet());
                ed_city.setText(address.getCity());
                ed_country.setText(address.getCountry());
                ed_pincode.setText(address.getPincode());
                ed_email.setText(address.getEmailid());
                ed_contactnum.setText(address.getMobileno());
                address_type = address.getType();
                if(address_type == 2){
                    toolbar.setTitle(ActivityTitle.getEditBillingActivityTitle(fthis));
                }
            }
        }
        catch (Exception ee){
            ee.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    class EditAddress extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(EditAddressActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("id", str_addressid);
                objData.put("fname", str_fname);
                objData.put("lname", str_lname);
                objData.put("address1", str_address1);
                objData.put("address2", str_address2);
                objData.put("street", str_street);
                objData.put("city", str_city);
                objData.put("address_state", str_state);
                objData.put("country", str_country);
                objData.put("pincode", str_pincode);
                objData.put("contact", str_contactnum);
                objData.put("email_id", str_email);
                objData.put("address_type", address_type);

                jsonEditAddress = jsonParser.makeHttpRequestJSON(URLManager.createAddressURL(), "POST", objData);
                Log.d("jsonEditAddress", objData+"");
                Log.d("jsonEditAddress", jsonEditAddress+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonEditAddress != null){
                    JSONObject jsonObject = jsonEditAddress.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        Toast.makeText(getApplicationContext(), ErrorMessages.getAddressUpdatedMsg(fthis), Toast.LENGTH_SHORT).show();
                        finish();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnUpdate){
            if(ed_fname.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyFName(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_lname.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyLName(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_address1.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyAddress(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_city.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyCity(fthis), Toast.LENGTH_LONG).show();
            }else if(sp_State.getSelectedItemPosition() == 0){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyState(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_pincode.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyPincode(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_pincode.getText().toString().trim().length() != 6){
                Toast.makeText(getApplicationContext(), ErrorMessages.getInvalidPincode(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_email.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyEmail(fthis), Toast.LENGTH_LONG).show();
            }else if(!Helper.validateEmailAddress(ed_email.getText().toString().trim())){
                Toast.makeText(getApplicationContext(), ErrorMessages.getInvalidEmail(fthis), Toast.LENGTH_LONG).show();
            }else if(ed_contactnum.getText().toString().trim().length() != 10){
                Toast.makeText(getApplicationContext(), ErrorMessages.getInvalidMobileNum(fthis), Toast.LENGTH_LONG).show();
            }else{
                str_addressid = address.getId();
                str_fname = ed_fname.getText().toString();
                str_lname = ed_lname.getText().toString();
                str_address1 = ed_address1.getText().toString();
                str_address2 = ed_address2.getText().toString();
                str_street = ed_street.getText().toString();
                str_city = ed_city.getText().toString();
                str_state = sp_State.getSelectedItemPosition()+"";
                str_country = "India";
                str_pincode = ed_pincode.getText().toString();
                str_email = ed_email.getText().toString();
                str_contactnum = ed_contactnum.getText().toString();
                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(EditAddressActivity.this);
                if(!networkDetails.isEmpty()) {
                    new EditAddress().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(EditAddressActivity.this), Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
