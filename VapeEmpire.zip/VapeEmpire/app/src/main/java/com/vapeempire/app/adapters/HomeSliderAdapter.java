package com.vapeempire.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.Image;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.vapeempire.app.R;
import com.vapeempire.app.activities.ProductDetailActivity;
import com.vapeempire.app.models.Product;
import com.vapeempire.app.utils.URLManager;

import java.util.ArrayList;

/**
 * Created by Rahul on 7/25/17.
 */

public class HomeSliderAdapter extends RecyclerView.Adapter<HomeSliderAdapter.HomeSliderViewHolder> {
    ArrayList<Product> objProduct = new ArrayList<Product>();
    Context ctx;
    RecyclerView resourceIdd;
    public HomeSliderAdapter(ArrayList<Product> objProduct, Context ctx, RecyclerView resourceIdd){
        this.objProduct = objProduct;
        this.ctx = ctx;
        this.resourceIdd = resourceIdd;
    }
    @Override
    public HomeSliderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_hslider_column, parent, false);
        HomeSliderViewHolder contactViewHolder = new HomeSliderViewHolder(view, ctx, objProduct, resourceIdd);
        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(HomeSliderViewHolder holder, int position) {
        Picasso.with(ctx).load(URLManager.getPRODUCTIMGURL(this.objProduct.get(position).getProductIcon())).into(holder.grid_product_image);
    }
    @Override
    public int getItemCount() {
        return objProduct.size();
    }
    public static class HomeSliderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private ImageView grid_product_image;
        private CardView cardview_row_fproduct;
        Context mctx;
        ArrayList<Product> products;
        public HomeSliderViewHolder(View view, Context ctx, ArrayList<Product> objProduct, RecyclerView resourceIdd){
            super(view);
            this.products = objProduct;
            this.mctx = ctx;
            this.cardview_row_fproduct = (CardView) view.findViewById(R.id.cardview_row_fproduct);
            this.cardview_row_fproduct.setOnClickListener(this);
            this.grid_product_image = (ImageView)view.findViewById(R.id.grid_product_image);
        }

        @Override
        public void onClick(View v) {
            Product product = this.products.get(getAdapterPosition());
            Intent intent = new Intent(mctx, ProductDetailActivity.class);
            intent.putExtra("productid", product.getProductId());
            intent.putExtra("brandid", product.getBrandid());
            intent.putExtra("catid", product.getCatid());
            intent.putExtra("productname", product.getProductName());
            mctx.startActivity(intent);
        }
    }
}
