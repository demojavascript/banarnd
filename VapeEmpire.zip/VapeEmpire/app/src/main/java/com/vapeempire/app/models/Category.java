package com.vapeempire.app.models;

/**
 * Created by Rahul on 6/18/17.
 */

public class Category {
    private String catid;
    private String title;
    private String icon;
    private int total_product;
    private int total_child;
    private int total_brand;
    private String desc;

    public Category(){

    }
    public Category(String catid, String title, String icon, int total_product, int total_child, int total_brand, String desc){
        this.catid = catid;
        this.title = title;
        this.icon = icon;
        this.total_brand = total_brand;
        this.total_child = total_child;
        this.total_product = total_product;
        this.desc = desc;
    }

    public void setCatid(String catid){
        this.catid = catid;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public void setIcon(String icon){
        this.icon = icon;
    }
    public void setDesc(String desc){
        this.desc = desc;
    }
    public void setTotal_product(int total_product){
        this.total_product = total_product;
    }
    public void setTotal_brand(int total_brand){
        this.total_brand = total_brand;
    }
    public void setTotal_child(int total_child){
        this.total_child = total_child;
    }

    public String getCatid(){
        return this.catid;
    }
    public String getTitle(){
        return this.title;
    }
    public String getIcon(){
        return this.icon;
    }
    public String getDesc(){
        return this.desc;
    }
    public int getTotal_product(){
        return this.total_product;
    }
    public int getTotal_brand(){
        return this.total_brand;
    }
    public int getTotal_child(){
        return this.total_child;
    }
}
