package com.vapeempire.app.models;

/**
 * Created by Rahul on 7/22/17.
 */

public class Slider {
    private String title;
    private String desc;
    private String url;
    private String type;
    private String id;

    public Slider(){

    }

    public Slider(String title, String desc, String url, String type, String id){
        this.title = title;
        this.desc = desc;
        this.url = url;
        this.id = id;
        this.type = type;
    }

    public void setTitle(String title){
        this.title = title;
    }
    public void setDesc(String desc){
        this.desc = desc;
    }
    public void setUrl(String url){
        this.url = url;
    }
    public void setType(String type){
        this.type = type;
    }
    public void setId(String id){
        this.id = id;
    }
    public String getTitle(){
        return this.title;
    }
    public String getDesc(){
        return this.desc;
    }
    public String getUrl(){
        return this.url;
    }
    public String getId(){
        return this.id;
    }
    public String getType(){
        return this.type;
    }
}
