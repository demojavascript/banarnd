package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class OrderPlaceActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private OrderPlaceActivity fthis;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json, jsonOrder;
    private NetConnection netConnection;
    private SharedPrefManager sharedPrefManager;

    private Double totalMrp   = 0.0, totalAmount = 0.0, couponAnount, shippingAmount = 0.0, totalPayable = 0.0;
    private int totalQuantity = 0;
    private Boolean isCoupon = false;
    private String couponCode = "", selAddressId="", invoiceId = "", selBillingId="";

    private LinearLayout lout_coupon1, lout_coupon2;
    private TextView tv_Quantity, tv_totalMRP, tv_totalAmount, tv_couponCode, tv_couponAmount, tv_payableAmount, tv_shippingAmount;
    private Button btnPay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_place);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;

        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getOrderPlaceActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        lout_coupon1 = (LinearLayout)findViewById(R.id.lout_coupon1);
        lout_coupon2 = (LinearLayout)findViewById(R.id.lout_coupon2);
        tv_couponAmount = (TextView)findViewById(R.id.tv_couponAmount);
        tv_couponCode = (TextView)findViewById(R.id.tv_couponCode);
        tv_payableAmount = (TextView)findViewById(R.id.tv_payableAmount);
        tv_Quantity = (TextView)findViewById(R.id.tv_Quantity);
        tv_totalMRP = (TextView)findViewById(R.id.tv_totalMRP);
        tv_totalAmount = (TextView)findViewById(R.id.tv_totalAmount);
        tv_shippingAmount = (TextView)findViewById(R.id.tv_shippingAmount);
        btnPay = (Button)findViewById(R.id.btnPay);
        btnPay.setOnClickListener(this);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                totalAmount = intent.getExtras().getDouble("totalamount");
                totalMrp = intent.getExtras().getDouble("mrp");
                totalQuantity = intent.getExtras().getInt("quantity");
                selAddressId = intent.getExtras().getString("addressid");
                selBillingId = intent.getExtras().getString("baddressid");
                isCoupon = intent.getExtras().getBoolean("iscoupon");
                totalPayable = intent.getExtras().getDouble("totalPayable");
                shippingAmount = intent.getExtras().getDouble("shippingAmount");
                if(isCoupon) {
                    lout_coupon1.setVisibility(View.VISIBLE);
                    lout_coupon2.setVisibility(View.VISIBLE);
                    couponAnount = intent.getExtras().getDouble("couponamount");
                    couponCode = intent.getExtras().getString("couponcode");
                    tv_couponAmount.setText(couponAnount+"");
                    tv_couponCode.setText(couponCode+"");
                }
                tv_shippingAmount.setText(shippingAmount+"");
                tv_totalMRP.setText(totalMrp+"");
                tv_totalAmount.setText(totalAmount+"");
                tv_payableAmount.setText(totalPayable+"");
                tv_Quantity.setText(totalQuantity+"");

            }
        }catch(Exception ee){
            ee.printStackTrace();
        }
    }

    class PendingOrderPlacing extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(OrderPlaceActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("coupon_code", couponCode);
                objData.put("address_id", selAddressId);
                objData.put("address_billing_id", selBillingId);
                objData.put("status", 1);
                objData.put("payment_type", 1);
                Log.d("jdon", objData+"  "+selAddressId);
                json = jsonParser.makeHttpRequestJSON(URLManager.getSetOrderURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        invoiceId = jsonObject.getJSONObject("data").getString("invoice_id");
                        new OrderPlacing().execute();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class OrderPlacing extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(OrderPlaceActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("invoice_id", invoiceId);
                objData.put("status", 2);
                jsonOrder = jsonParser.makeHttpRequestJSON(URLManager.getUpdateOrderURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonOrder != null){
                    JSONObject jsonObject = jsonOrder.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        invoiceId = jsonObject.getJSONObject("data").getString("id");
                        sharedPrefManager.setCart_quantity(0);
                        Toast.makeText(getApplicationContext(), ErrorMessages.getOrderPlacedMsg(fthis), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(OrderPlaceActivity.this, OrderSuccessActivity.class);
                        intent.putExtra("invoiceid", invoiceId);
                        startActivity(intent);
                        finish();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnPay:
                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(OrderPlaceActivity.this);
                if(!networkDetails.isEmpty()) {
                    new PendingOrderPlacing().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(OrderPlaceActivity.this), Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
}
