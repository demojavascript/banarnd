package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.AddressListAdapter;
import com.vapeempire.app.adapters.CartAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Address;
import com.vapeempire.app.models.Cart;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class CartActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private CartActivity fthis;
    private static CartActivity inst;
    private SharedPrefManager sharedPrefManager;

    private ArrayList<Cart> cartList;
    private RecyclerView rvCart;
    private RecyclerView.Adapter adapterCartList;
    private RecyclerView.LayoutManager layoutManager;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;
    private Double totalAmount = 0.0, totalMrp = 0.0, shippingAmount = 0.0;
    private TextView tv_amount;
    private LinearLayout lout_nocartlist, lout_cartlist;
    private Button btnCheckout;
    private String product_id, id, ingredients, qty;
    private int cartCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getCartActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        cartCount = sharedPrefManager.getCart_quantity();

        btnCheckout = (Button)findViewById(R.id.btnCheckout);
        btnCheckout.setOnClickListener(this);
        tv_amount = (TextView)findViewById(R.id.tv_amount);
        lout_nocartlist = (LinearLayout)findViewById(R.id.lout_nocartlist);
        lout_cartlist = (LinearLayout)findViewById(R.id.lout_cartlist);

        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(fthis);
        if(!networkDetails.isEmpty()) {
            new GetMiniCart().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
        }

    }

    public void displayData(){
        if (cartList == null || cartList.size() == 0){
            lout_nocartlist.setVisibility(View.VISIBLE);
        }else{
            lout_cartlist.setVisibility(View.VISIBLE);
            rvCart = (RecyclerView)findViewById(R.id.recycleview_cartlist);
            layoutManager = new LinearLayoutManager(this);
            rvCart.setLayoutManager(layoutManager);
            rvCart.setHasFixedSize(true);
            adapterCartList = new CartAdapter(cartList, this, rvCart);
            rvCart.setAdapter(adapterCartList);
            tv_amount.setText(totalAmount+"");
        }

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnCheckout:
                Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
                intent.putExtra("totalamount", totalAmount);
                intent.putExtra("totalquantity", cartList.size());
                intent.putExtra("totalmrp", totalMrp);
                intent.putExtra("shippingAmount", shippingAmount);
                startActivity(intent);
                break;
        }
    }

    class GetMiniCart extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CartActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());

                json = jsonParser.makeHttpRequestJSON(URLManager.getMiniCartURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONArray("data") != null && jsonObject.getJSONArray("data").length() > 0){
                            cartList = new ArrayList<Cart>();
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                                Cart cart = new Cart(obj.getString("id"), obj.getString("product_id"), obj.getString("name"), obj.getString("user_id"), obj.getInt("ingredients"), obj.getInt("qty"), obj.getString("image"), obj.getString("product_size"), obj.getDouble("original_price"), obj.getDouble("discounted_price"));
                                cartList.add(cart);
                                totalAmount = totalAmount + (obj.getDouble("discounted_price")*obj.getInt("qty"));
                                totalMrp = totalMrp + (obj.getDouble("original_price")*obj.getInt("qty"));
                            }
                            shippingAmount = jsonObject.getDouble("shipping_amount");
                            displayData();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }


    class UpdateMiniCart extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CartActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id",product_id);
                objData.put("ingredients", ingredients);
                objData.put("qty", qty);
                objData.put("id", id);

                json = jsonParser.makeHttpRequestJSON(URLManager.getUpdateMiniCartURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        new GetMiniCartAgain().execute();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class DeleteMiniCart extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CartActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id",product_id);
                objData.put("ingredients", ingredients);

                json = jsonParser.makeHttpRequestJSON(URLManager.getDeleteMiniCartURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        new GetMiniCartAgain().execute();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class GetMiniCartAgain extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                json = jsonParser.makeHttpRequestJSON(URLManager.getMiniCartURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONArray("data") != null && jsonObject.getJSONArray("data").length() > 0){
                            cartList = new ArrayList<Cart>();
                            int rr = 0;
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                                Cart cart = new Cart(obj.getString("id"), obj.getString("product_id"), obj.getString("name"), obj.getString("user_id"), obj.getInt("ingredients"), obj.getInt("qty"), obj.getString("image"), obj.getString("product_size"), obj.getDouble("original_price"), obj.getDouble("discounted_price"));
                                cartList.add(cart);
                                totalAmount = totalAmount + (obj.getDouble("discounted_price")*obj.getInt("qty"));
                                totalMrp = totalMrp + (obj.getDouble("original_price")*obj.getInt("qty"));
                                rr++;
                            }
                            sharedPrefManager.setCart_quantity(rr);
                            cartCount = sharedPrefManager.getCart_quantity();
                            invalidateOptionsMenu();
                            displayData();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public void updateCart(String product_id, int ingredients, int qty, String id){
        this.product_id = product_id;
        this.ingredients = ingredients+"";
        this.qty = qty+"";
        this.id = id;
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(fthis);
        if(!networkDetails.isEmpty()) {
            new UpdateMiniCart().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
        }
    }
    public void deleteCart(String product_id, int ingredients){
        this.product_id = product_id;
        this.ingredients = ingredients+"";
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(fthis);
        if(!networkDetails.isEmpty()) {
            new DeleteMiniCart().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
        }
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.findItem(R.id.cartBadge);
        menuItem.setIcon(Helper.buildCounterDrawable(cartCount, R.drawable.ic_cart_w, this));
        return true;
    }*/
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        cartCount = sharedPrefManager.getCart_quantity();
        invalidateOptionsMenu();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        /*if (id == R.id.cartBadge) {
            if(cartCount != 0){
                Intent intent = new Intent(CartActivity.this, CartActivity.class);
                startActivity(intent);
            }
        }else*/
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
        inst = this;
    }
    public static CartActivity instance() {
        return inst;
    }
}
