package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class LoginActivity extends AppCompatActivity implements
        GoogleApiClient.OnConnectionFailedListener,
        View.OnClickListener {

    private LoginActivity fthis;
    private CallbackManager callbackManager;
    private SharedPrefManager sharedPrefManager;
    private LoginActivity loginActivity;

    private static final String TAG = "SignInActivity";
    private static final int FB_RC_SIGN_IN = 9001;
    private static final int GOOGLE_RC_SIGN_IN = 9002;
    private GoogleApiClient mGoogleApiClient;

    private String loginType, loginid = "", loginemail="", loginname, loginpic="", str_pwd="";
    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonUser;
    private NetConnection netConnection;
    private EditText ed_email, ed_password, ed_name;
    private Button btnLogin_lc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginActivity = this;
        fthis = this;
        sharedPrefManager = new SharedPrefManager(this);
        FacebookSdk.sdkInitialize(this.getApplicationContext());
        setContentView(R.layout.activity_login);

        //Local Login Zone
        ed_email = (EditText)findViewById(R.id.ed_email);
        ed_password = (EditText)findViewById(R.id.ed_password);
        ed_name = (EditText)findViewById(R.id.ed_name);
        btnLogin_lc = (Button)findViewById(R.id.btnLogin_lc);
        btnLogin_lc.setOnClickListener(this);
        //Local Login Zone

        //FB Login Zone
        callbackManager = CallbackManager.Factory.create();
        LoginButton loginButton = (LoginButton) findViewById(R.id.btnLogin_fb);
        loginButton.setReadPermissions("public_profile email");
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                FBRequestData();
            }
            @Override
            public void onCancel() {
                Toast.makeText(getApplicationContext(), ErrorMessages.getFBMsgCancel(fthis), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException exception) {
                Toast.makeText(getApplicationContext(), ErrorMessages.getFBMsgError(fthis), Toast.LENGTH_SHORT).show();
            }
        });
        //FB Login Zone

        //Google Login Zone
        findViewById(R.id.btnLogin_gplus).setOnClickListener(this);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        SignInButton signInButton = (SignInButton) findViewById(R.id.btnLogin_gplus);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        //Google Login Zone
    }
    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOOGLE_RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleGoogleSignInResult(result);
        }else {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void handleGoogleSignInResult(GoogleSignInResult result) {
        Log.d(TAG, "handleSignInResult:" + result.isSuccess());
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            if (acct.getPhotoUrl() != null) {
                loginpic = acct.getPhotoUrl().toString();
            }
            loginType = "google";
            loginemail = acct.getEmail();
            loginname = acct.getDisplayName();
            loginid = acct.getId();
            //sharedPrefManager.setUser("google", acct.getId(), acct.getEmail(), acct.getDisplayName(),  strpic, acct.getIdToken(), true);
            //startActivity(new Intent(LoginActivity.this, MainActivity.class));
            //finish();
            //Toast.makeText(getApplicationContext(), "Login "+acct.getEmail(), Toast.LENGTH_SHORT).show();
            netConnection = new NetConnection();
            Map<String, String> networkDetails = netConnection.getConnectionDetails(loginActivity);
            if(!networkDetails.isEmpty()) {
                new AttemptLogin().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(loginActivity), Toast.LENGTH_LONG).show();
            }
        } else {
            //Toast.makeText(getApplicationContext(), "Error - ", Toast.LENGTH_SHORT).show();
        }
    }


    public void FBRequestData(){
        GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {

                JSONObject json = response.getJSONObject();
                //System.out.println("Json data :"+json);
                try {
                    if(json != null){
                        //String text = "<b>Name :</b> "+json.getString("name")+"<br><br><b>Email :</b> "+json.getString("email")+"<br><br><b>Profile link :</b> "+json.getString("link");
                        //details_txt.setText(Html.fromHtml(text));
                        loginType = "facebook";
                        loginemail = json.getString("email");
                        loginname = json.getString("name");
                        loginid = json.getString("id");
                        loginpic = json.getJSONObject("picture").getJSONObject("data").getString("url");
                        //sharedPrefManager.setUser("facebook", json.getString("id"), json.getString("email"), json.getString("name"),  json.getJSONObject("picture").getJSONObject("data").getString("url"), AccessToken.getCurrentAccessToken().getToken(), true);
                        //startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        //finish();
                        netConnection = new NetConnection();
                        Map<String, String> networkDetails = netConnection.getConnectionDetails(loginActivity);
                        if(!networkDetails.isEmpty()) {
                            new AttemptLogin().execute();
                        }else{
                            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(loginActivity), Toast.LENGTH_LONG).show();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,link,email,picture");
        request.setParameters(parameters);
        request.executeAsync();
    }

    class AttemptLogin extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(loginActivity);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("acces_token", loginid);
                objData.put("login_by", loginType);
                objData.put("name", loginname);
                objData.put("is_login", true);
                objData.put("email_id", loginemail);
                objData.put("password", str_pwd);
                objData.put("os", sharedPrefManager.getDeviceOs());
                jsonUser = jsonParser.makeHttpRequestJSON(URLManager.getLoginURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", jsonUser+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonUser != null){
                    JSONObject jsonObject = jsonUser.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        JSONObject udata = jsonObject.getJSONObject("data");

                        sharedPrefManager.setUser(loginType, loginid, udata.getString("email_id"),loginname, loginpic, true);
                        if(!udata.getString("dob").equals(null)) {
                            sharedPrefManager.setUdob(udata.getString("dob"));
                        }
                        if(udata.getString("gender") != null && udata.getString("gender").length() > 0) {
                            sharedPrefManager.setUgender(Integer.parseInt(udata.getString("gender")));
                        }
                        if(udata.getString("marital_status") != null &&  udata.getString("marital_status").length() > 0) {
                            sharedPrefManager.setUmstatus(Integer.parseInt(udata.getString("marital_status")));
                        }
                        if(udata.getString("phone_number") != null) {
                            sharedPrefManager.setPhone_number(udata.getString("phone_number"));
                        }

                        Intent intent = new Intent(loginActivity, MainActivity.class);
                        startActivity(intent);
                        finishAffinity();

                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, GOOGLE_RC_SIGN_IN);
    }
    private void signInLocal() {
        if(ed_email.getText().toString().trim().length() == 0){
            Toast.makeText(getApplicationContext(), ErrorMessages.getEmailEmpty(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else if(!Helper.validateEmailAddress(ed_email.getText().toString().trim())){
            Toast.makeText(getApplicationContext(), ErrorMessages.getEmailIncorrect(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else if(ed_password.getText().toString().trim().length() == 0){
            Toast.makeText(getApplicationContext(), ErrorMessages.getPwdEmpty(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else if( (ed_password.getText().toString().trim().length() <6) || (ed_password.getText().toString().trim().length() > 10) ){
            Toast.makeText(getApplicationContext(), ErrorMessages.getPwdLength(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else if(ed_name.getText().toString().trim().length() == 0){
            Toast.makeText(getApplicationContext(), ErrorMessages.getNameEmpty(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else if(ed_name.getText().toString().length() < 6){
            Toast.makeText(getApplicationContext(), ErrorMessages.getNameLength(LoginActivity.this), Toast.LENGTH_SHORT).show();
        }else{
            str_pwd = ed_password.getText().toString().trim();
            try {
                loginid = Helper.createTransactionID();
            }catch(Exception ee){
                ee.printStackTrace();
            }
            loginType = "local";
            loginname = ed_name.getText().toString().trim();
            loginemail = ed_email.getText().toString().trim();

            netConnection = new NetConnection();
            Map<String, String> networkDetails = netConnection.getConnectionDetails(loginActivity);
            if(!networkDetails.isEmpty()) {
                new AttemptLogin().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(loginActivity), Toast.LENGTH_LONG).show();
            }

        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnLogin_gplus){
            signIn();
        }
        if(view.getId() == R.id.btnLogin_lc){
            signInLocal();
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}

