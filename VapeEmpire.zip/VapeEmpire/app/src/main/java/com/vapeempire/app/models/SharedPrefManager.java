package com.vapeempire.app.models;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Rahul on 6/11/17.
 */

public class SharedPrefManager {
    private Context context;
    private SharedPreferences sharedpreferences;
    private static final String MyPREFERENCES    = "vapeSharedPrefs";

    private static final String UserAgreeID      = "18yearagreeKey";
    private static final String loginType        = "logintypekey";
    private static final String userId           = "useridkey";
    private static final String email            = "emailkey";
    private static final String uname            = "unamekey";
    private static final String udob             = "udobkey";
    private static final String umstatus         = "umstatuskey";
    private static final String ugender          = "ugenderkey";
    private static final String upicurl          = "picurlkey";
    private static final String accessToken      = "accesstokenkey";
    private static final String isLogin          = "isloginkey";
    private static final String deviceID         = "deviceidKey";
    private static final String deviceOs         = "osKey";
    private static final String phone_number     = "phone_numberKey";

    private static final String billing_address1 = "billing_address1Key";
    private static final String billing_address2 = "billing_address2Key";
    private static final String billing_street   = "billing_streetKey";
    private static final String billing_city     = "billing_cityKey";
    private static final String billing_state    = "billing_stateKey";
    private static final String billing_country  = "billing_countryKey";
    private static final String billing_pincode  = "billing_pincodeKey";
    private static final String billing_contact  = "billing_contactKey";
    private static final String billing_emailid  = "billing_emailidKey";

    public SharedPrefManager(Context context){
        this.context = context;
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
    }
    public void setUserAgree(String userAgreeID){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(UserAgreeID, userAgreeID);
        editor.commit();
    }
    public void setDeviceOs(String od){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(deviceOs, od);
        editor.commit();
    }
    public void setDeviceID(String deviceid){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(deviceID, deviceid);
        editor.commit();
    }
    public String getUserAgree(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(UserAgreeID, "0");
    }
    public void setEmail(String _Eamil){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(email, _Eamil);
        editor.commit();
    }
    public void setUser(String uloginType, String uuserId, String uemail, String uuname, String picurl, boolean uisLogin){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(loginType, uloginType);
        editor.putString(userId, uuserId);
        editor.putString(email, uemail);
        editor.putString(uname, uuname);
        editor.putString(upicurl, picurl);
        editor.putBoolean(isLogin, uisLogin);
        editor.commit();
    }
    public void logout(){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(loginType, "");
        editor.putString(userId, "");
        editor.putString(uname, "");
        editor.putString(upicurl, "");
        editor.putString(email, "");
        editor.putString(accessToken, "");
        editor.putBoolean(isLogin, false);
        editor.putString(udob, "");
        editor.putInt(umstatus, 0);
        editor.putInt(ugender, 0);
        editor.putString(phone_number, "");
        editor.putString(billing_address1, "");
        editor.putString(billing_address2, "");
        editor.putString(billing_street, "");
        editor.putString(billing_city, "");
        editor.putString(billing_state, "");
        editor.putString(billing_country, "");
        editor.putString(billing_pincode, "");
        editor.putString(billing_contact, "");
        editor.putString(billing_emailid, "");
        editor.commit();
    }
    public void setUdob(String  dob){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(udob, dob);
        editor.commit();
    }
    public void setUmstatus(int mstatus){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(umstatus, mstatus);
        editor.commit();
    }
    public void setUgender(int gender){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(ugender, gender);
        editor.commit();
    }


    public String getLoginType(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(loginType, "");
    }
    public String getUserId(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(userId, "");
    }
    public String getEmail(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(email, "");
    }
    public String getUname(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(uname, "");
    }
    public String getUdob(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(udob, "");
    }
    public int getUmstatus(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getInt(umstatus, 0);
    }
    public int getUgender(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getInt(ugender, 0);
    }
    public String getUpicurl(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(upicurl, "");
    }
    public String getAccessToken(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(accessToken, "");
    }
    public boolean getIsLogin(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean(isLogin, false);
    }
    public String getDeviceOs(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(deviceOs, "");
    }
    public String getDeviceID(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(deviceID, "");
    }

    public void setPhone_number(String c_number){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(phone_number, c_number);
        editor.commit();
    }
    public void setBilling_address1(String billing_address){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_address1, billing_address);
        editor.commit();
    }
    public void setBilling_address2(String billing_address){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_address2, billing_address);
        editor.commit();
    }
    public void setBilling_street(String street){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_street, street);
        editor.commit();
    }
    public void setBilling_city(String city){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_city, city);
        editor.commit();
    }
    public void setBilling_state(String state){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_state, state);
        editor.commit();
    }
    public void setBilling_country(String country){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_country, country);
        editor.commit();
    }
    public void setBilling_pincode(String pincode){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_pincode, pincode);
        editor.commit();
    }
    public void setBilling_emailid(String email){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_emailid, email);
        editor.commit();
    }
    public void setBilling_contact(String contact){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(billing_contact, contact);
        editor.commit();
    }


    public String getPhone_number(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(phone_number, "");
    }
    public String getBilling_address1(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_address1, "");
    }
    public String getBilling_address2(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_address2, "");
    }
    public String getBilling_street(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_street, "");
    }
    public String getBilling_city(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_city, "");
    }
    public String getBilling_state(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_state, "");
    }
    public String getBilling_country(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_country, "");
    }
    public String getBilling_pincode(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_pincode, "");
    }
    public String getBilling_emailid(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_emailid, "");
    }
    public String getBilling_contact(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(billing_contact, "");
    }
}
