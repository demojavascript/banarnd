package com.vapeempire.app.models;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Rahul on 6/11/17.
 */

public class SharedPrefManager {
    private Context context;
    private SharedPreferences sharedpreferences;
    private static final String MyPREFERENCES    = "vapeSharedPrefsv4";

    private static final String UserAgreeID      = "18yearagreeKey";
    private static final String loginType        = "logintypekey";
    private static final String userId           = "useridkey";
    private static final String email            = "emailkey";
    private static final String uname            = "unamekey";
    private static final String udob             = "udobkey";
    private static final String umstatus         = "umstatuskey";
    private static final String ugender          = "ugenderkey";
    private static final String upicurl          = "picurlkey";
    private static final String accessToken      = "accesstokenkey";
    private static final String isLogin          = "isloginkey";
    private static final String deviceID         = "deviceidKey";
    private static final String deviceOs         = "osKey";
    private static final String phone_number     = "phone_numberKey";
    private static final String cart_quantity    = "cart_quantity";

    public SharedPrefManager(Context context){
        this.context = context;
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
    }
    public void setUserAgree(String userAgreeID){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(UserAgreeID, userAgreeID);
        editor.commit();
    }
    public void setCart_quantity(int qty){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(cart_quantity, qty);
        editor.commit();
    }
    public void setDeviceOs(String od){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(deviceOs, od);
        editor.commit();
    }
    public void setDeviceID(String deviceid){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(deviceID, deviceid);
        editor.commit();
    }
    public String getUserAgree(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(UserAgreeID, "0");
    }
    public void setEmail(String _Eamil){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(email, _Eamil);
        editor.commit();
    }
    public void setUser(String uloginType, String uuserId, String uemail, String uuname, String picurl, boolean uisLogin){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(loginType, uloginType);
        editor.putString(userId, uuserId);
        editor.putString(email, uemail);
        editor.putString(uname, uuname);
        editor.putString(upicurl, picurl);
        editor.putBoolean(isLogin, uisLogin);
        editor.commit();
    }
    public void logout(){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(loginType, "");
        editor.putString(userId, "");
        editor.putString(uname, "");
        editor.putString(upicurl, "");
        editor.putString(email, "");
        editor.putString(accessToken, "");
        editor.putBoolean(isLogin, false);
        editor.putString(udob, "");
        editor.putInt(umstatus, 0);
        editor.putInt(ugender, 0);
        editor.putString(phone_number, "");
        editor.commit();
    }
    public void setUdob(String  dob){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(udob, dob);
        editor.commit();
    }
    public void setUmstatus(int mstatus){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(umstatus, mstatus);
        editor.commit();
    }
    public void setUgender(int gender){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt(ugender, gender);
        editor.commit();
    }
    public String getLoginType(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(loginType, "");
    }
    public int getCart_quantity(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getInt(cart_quantity, 0);
    }
    public String getUserId(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(userId, "");
    }
    public String getEmail(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(email, "");
    }
    public String getUname(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(uname, "");
    }
    public String getUdob(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(udob, "");
    }
    public int getUmstatus(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getInt(umstatus, 0);
    }
    public int getUgender(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getInt(ugender, 0);
    }
    public String getUpicurl(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(upicurl, "");
    }
    public String getAccessToken(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(accessToken, "");
    }
    public boolean getIsLogin(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean(isLogin, false);
    }
    public String getDeviceOs(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(deviceOs, "");
    }
    public String getDeviceID(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(deviceID, "");
    }

    public void setPhone_number(String c_number){
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(phone_number, c_number);
        editor.commit();
    }
    public String getPhone_number(){
        sharedpreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        return sharedpreferences.getString(phone_number, "");
    }
}
