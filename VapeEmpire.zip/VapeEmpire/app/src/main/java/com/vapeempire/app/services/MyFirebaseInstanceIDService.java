package com.vapeempire.app.services;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.vapeempire.app.models.SharedPrefManager;

/**
 * Created by Rahul on 01-07-2016.
 */
public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    private SharedPrefManager sharedPrefManager;

    @Override
    public void onTokenRefresh() {
        sharedPrefManager = new SharedPrefManager(this);
        Log.d("deviceid", FirebaseInstanceId.getInstance().getToken());
        sharedPrefManager.setDeviceID(FirebaseInstanceId.getInstance().getToken());
        sharedPrefManager.setDeviceOs("android");
    }
}