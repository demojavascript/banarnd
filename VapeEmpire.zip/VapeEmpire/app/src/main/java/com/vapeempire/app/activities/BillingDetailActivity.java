package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class BillingDetailActivity extends AppCompatActivity implements View.OnClickListener,
        AdapterView.OnItemSelectedListener  {
    private Toolbar toolbar;
    private BillingDetailActivity fthis;
    private SharedPrefManager sharedPrefManager;
    private Spinner sp_State;
    private String[] state;
    private ArrayAdapter<String> stateAdapter;
    private EditText ed_billing_address1, ed_billing_address2, ed_billing_street, ed_billing_city, ed_billing_country, ed_billing_pincode,ed_billing__email, ed_billing_contactnum;
    private Button btnUpdate;
    private String str_address1, str_address2, str_street, str_city, str_state, str_country, str_pincode, str_email, str_contactnum;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billing_detail);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getBillingActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Resources objres = getResources();
        state = objres.getStringArray(R.array.allState);
        sp_State = (Spinner)findViewById(R.id.sp_State);
        sp_State.setOnItemSelectedListener(this);
        stateAdapter =  new ArrayAdapter(this,android.R.layout.simple_spinner_item, state);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_State.setAdapter(stateAdapter);


        ed_billing_address1 = (EditText)findViewById(R.id.ed_billing_address1);
        ed_billing_address2 = (EditText)findViewById(R.id.ed_billing_address2);
        ed_billing_street = (EditText)findViewById(R.id.ed_billing_street);
        ed_billing_city = (EditText)findViewById(R.id.ed_billing_city);
        ed_billing_country = (EditText)findViewById(R.id.ed_billing_country);
        ed_billing_pincode = (EditText)findViewById(R.id.ed_billing_pincode);
        ed_billing__email = (EditText)findViewById(R.id.ed_billing_email);
        ed_billing_contactnum = (EditText)findViewById(R.id.ed_billing_contactnum);
        btnUpdate = (Button)findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);



    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    class BillingDetailUpdate extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(BillingDetailActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("acces_token", sharedPrefManager.getUserId());
                objData.put("login_by", sharedPrefManager.getLoginType());
                objData.put("name", sharedPrefManager.getUname());
                objData.put("is_login", true);
                objData.put("os", sharedPrefManager.getDeviceOs());
                objData.put("billing_address1", str_address1);
                objData.put("billing_address2", str_address2);
                objData.put("billing_street", str_street);
                objData.put("billing_city", str_city);
                objData.put("billing_state", str_state);
                objData.put("billing_country", str_country);
                objData.put("billing_pincode", str_pincode);
                objData.put("billing_contact", str_contactnum);
                objData.put("billing_email_id", str_email);

                json = jsonParser.makeHttpRequestJSON(URLManager.billingInfoURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        JSONObject udata = jsonObject.getJSONObject("data");
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnUpdate){
            if(ed_billing_address1.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), "Enter Billing address", Toast.LENGTH_LONG).show();
            }else if(ed_billing_city.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), "Enter Billing city", Toast.LENGTH_LONG).show();
            }else if(sp_State.getSelectedItemPosition() == 0){
                Toast.makeText(getApplicationContext(), "Enter Billing state", Toast.LENGTH_LONG).show();
            }else if(ed_billing_pincode.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), "Enter Billing pincode", Toast.LENGTH_LONG).show();
            }else if(ed_billing_pincode.getText().toString().trim().length() != 6){
                Toast.makeText(getApplicationContext(), "Enter valid pincode"+ed_billing_pincode.toString().trim().length(), Toast.LENGTH_LONG).show();
            }else if(ed_billing__email.getText().toString().trim().length() < 1){
                Toast.makeText(getApplicationContext(), "Enter Billing email address", Toast.LENGTH_LONG).show();
            }else if(!Helper.validateEmailAddress(ed_billing__email.getText().toString().trim())){
                Toast.makeText(getApplicationContext(), "Enter valid email address", Toast.LENGTH_LONG).show();
            }else if(ed_billing_contactnum.getText().toString().trim().length() < 10){
                Toast.makeText(getApplicationContext(), "Enter correct contact number", Toast.LENGTH_LONG).show();
            }else{
                str_address1 = ed_billing_address1.getText().toString();
                str_address2 = ed_billing_address2.getText().toString();
                str_street = ed_billing_street.getText().toString();
                str_city = ed_billing_city.getText().toString();
                str_state = sp_State.getSelectedItemPosition()+"";
                str_country = "India";
                str_pincode = ed_billing_pincode.getText().toString();
                str_email = ed_billing__email.getText().toString();
                str_contactnum = ed_billing_contactnum.getText().toString();
                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(BillingDetailActivity.this);
                if(!networkDetails.isEmpty()) {
                    new BillingDetailUpdate().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(BillingDetailActivity.this), Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
