package com.vapeempire.app.utils;

/**
 * Created by Rahul on 6/9/17.
 */

public class AppText {
}
