package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.AddressListAdapter;
import com.vapeempire.app.adapters.AddressSelectAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Address;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class CheckoutActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private CheckoutActivity fthis;
    private static CheckoutActivity inst;

    private ArrayList<Address> objAddresses;
    private RecyclerView rvAddress, recycleview_billingaddressselect;
    private RecyclerView.Adapter adapterAddressList;
    private RecyclerView.LayoutManager layoutManager;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonApplyCoupon, jsonBilling, jsonShipping;
    private NetConnection netConnection;
    private SharedPrefManager sharedPrefManager;

    private Button btnAddNewAddress;
    private RelativeLayout reloutAddressList, reloutSummary, reloutBillingAddressList;
    private LinearLayout lout_coupon_1, lout_coupon_2;
    private int totalQuantity = 0;
    private Double totalPayable = 0.0, totalAmount = 0.0, totalMrp = 0.0, grandTotal=0.0, shippingAmount = 0.0;
    private TextView tv_shippingAmount, tv_totalMRP, tv_totalAmount, tv_Quantity, tv_PayableAmount, tv_CouponAmount, tv_CouponCode, tv_full_ship_address, tv_full_bill_address;
    private EditText ed_couponCode;
    private Button btnApplyCode, btn_PayNow, btnAddNewBillingAddress;
    private String selAddressId = "", selBillingId="", couponCode, ship_full_address = "", bill_full_address = "";
    private Boolean isCouponApplied = false;
    private int address_type = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;

        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getCheckoutActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnAddNewAddress = (Button)findViewById(R.id.btnAddNewAddress);
        btnAddNewAddress.setOnClickListener(this);
        btnAddNewBillingAddress = (Button)findViewById(R.id.btnAddNewBillingAddress);
        btnAddNewBillingAddress.setOnClickListener(this);
        reloutBillingAddressList = (RelativeLayout)findViewById(R.id.reloutBillingAddressList);
        reloutAddressList = (RelativeLayout)findViewById(R.id.reloutAddressList);
        reloutSummary = (RelativeLayout)findViewById(R.id.reloutSummary);

        lout_coupon_1 = (LinearLayout) findViewById(R.id.lout_coupon_1);
        lout_coupon_2 = (LinearLayout) findViewById(R.id.lout_coupon_2);

        tv_totalMRP = (TextView)findViewById(R.id.tv_totalMRP);
        tv_totalAmount = (TextView)findViewById(R.id.tv_totalAmount);
        tv_Quantity = (TextView)findViewById(R.id.tv_Quantity);
        tv_PayableAmount = (TextView)findViewById(R.id.tv_PayableAmount);
        tv_CouponAmount = (TextView)findViewById(R.id.tv_CouponAmount);
        tv_CouponCode = (TextView)findViewById(R.id.tv_CouponCode);
        tv_shippingAmount = (TextView)findViewById(R.id.tv_shippingAmount);

        ed_couponCode = (EditText)findViewById(R.id.ed_couponCode);

        tv_full_bill_address = (TextView)findViewById(R.id.tv_full_bill_address);
        tv_full_ship_address = (TextView)findViewById(R.id.tv_full_ship_address);

        btnApplyCode = (Button)findViewById(R.id.btnApplyCode);
        btnApplyCode.setOnClickListener(this);
        btn_PayNow = (Button)findViewById(R.id.btn_PayNow);
        btn_PayNow.setOnClickListener(this);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                totalAmount = intent.getExtras().getDouble("totalamount");
                totalMrp = intent.getExtras().getDouble("totalmrp");
                totalQuantity = intent.getExtras().getInt("totalquantity");
                shippingAmount = intent.getExtras().getDouble("shippingAmount");
                totalPayable = totalAmount + shippingAmount;

                tv_totalMRP.setText(totalMrp+"");
                tv_totalAmount.setText(totalAmount+"");
                tv_Quantity.setText(totalQuantity+"");
                tv_PayableAmount.setText(totalPayable+"");
                tv_shippingAmount.setText(shippingAmount+"");
            }
        }catch(Exception ee){
            ee.printStackTrace();
        }

    }

    public void displayShippingData(){
        reloutAddressList.setVisibility(View.VISIBLE);
        rvAddress = (RecyclerView)findViewById(R.id.recycleview_addressselect);
        layoutManager = new LinearLayoutManager(this);
        rvAddress.setLayoutManager(layoutManager);
        rvAddress.setHasFixedSize(true);
        adapterAddressList = new AddressSelectAdapter(objAddresses, this, rvAddress);
        rvAddress.setAdapter(adapterAddressList);
    }

    public void displayBillingData(){
        reloutBillingAddressList.setVisibility(View.VISIBLE);
        recycleview_billingaddressselect = (RecyclerView)findViewById(R.id.recycleview_billingaddressselect);
        layoutManager = new LinearLayoutManager(this);
        recycleview_billingaddressselect.setLayoutManager(layoutManager);
        recycleview_billingaddressselect.setHasFixedSize(true);
        adapterAddressList = new AddressSelectAdapter(objAddresses, this, recycleview_billingaddressselect);
        recycleview_billingaddressselect.setAdapter(adapterAddressList);
    }

    public void applyCoupon(){
        if(ed_couponCode.getText().toString().trim().length()  == 0) {
            Toast.makeText(getApplicationContext(), ErrorMessages.getEmptyCouponCode(fthis), Toast.LENGTH_LONG).show();;
        }else{
            couponCode = ed_couponCode.getText().toString().trim().toString();
            netConnection = new NetConnection();
            Map<String, String> networkDetails = netConnection.getConnectionDetails(CheckoutActivity.this);
            if(!networkDetails.isEmpty()) {
                new ApplyingCoupon().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(CheckoutActivity.this), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnAddNewBillingAddress:
                Intent intent3 = new Intent(CheckoutActivity.this, AddAddressActivity.class);
                intent3.putExtra("address_type", 2);
                startActivity(intent3);
                break;
            case R.id.btnAddNewAddress:
                Intent intent2 = new Intent(CheckoutActivity.this, AddAddressActivity.class);
                intent2.putExtra("address_type", 1);
                startActivity(intent2);
                break;
            case R.id.btnApplyCode:
                if(!isCouponApplied) {
                    applyCoupon();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getCouponAlreadyApplied(fthis), Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_PayNow:
                Intent intent = new Intent(CheckoutActivity.this, OrderPlaceActivity.class);
                intent.putExtra("quantity", totalQuantity);
                intent.putExtra("mrp", totalMrp);
                intent.putExtra("totalamount", totalAmount);
                intent.putExtra("addressid", selAddressId);
                intent.putExtra("baddressid", selBillingId);
                intent.putExtra("iscoupon", isCouponApplied);
                intent.putExtra("shippingAmount", shippingAmount);
                intent.putExtra("totalPayable", totalPayable);
                intent.putExtra("totalamount", totalAmount);
                if(isCouponApplied){
                    intent.putExtra("iscoupon", isCouponApplied);
                    intent.putExtra("couponcode", couponCode);
                    intent.putExtra("couponamount", (totalAmount - grandTotal));

                    intent.putExtra("totalPayable", totalPayable);
                }
                startActivity(intent);
                break;
        }
    }

    class ApplyingCoupon extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CheckoutActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("coupon_code", couponCode);
                jsonApplyCoupon = jsonParser.makeHttpRequestJSON(URLManager.getApplyCouponURL(), "POST", objData);
                Log.d("jsonApplyCoupon", objData+"");
                Log.d("jsonApplyCoupon", jsonApplyCoupon+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonApplyCoupon != null){
                    JSONObject jsonObject = jsonApplyCoupon.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        grandTotal = Double.parseDouble(jsonObject.getJSONObject("data").getString("grand_total"));
                        applyingCoupon();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }


    public void applyingCoupon(){
        lout_coupon_1.setVisibility(View.VISIBLE);
        lout_coupon_2.setVisibility(View.VISIBLE);
        tv_CouponCode.setText(couponCode);
        Double couponamnt = totalAmount - grandTotal;
        tv_CouponAmount.setText(couponamnt+"");
        totalPayable = grandTotal + shippingAmount;
        tv_PayableAmount.setText(totalPayable+"");

        ed_couponCode.setText("");
        isCouponApplied = true;
    }

    class GetShippingAddresses extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CheckoutActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("address_type", 1);
                jsonShipping = jsonParser.makeHttpRequestJSON(URLManager.getAddressURL(), "POST", objData);
                Log.d("jsonShipping", objData+"");
                Log.d("jsonShipping", jsonShipping+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonShipping != null){
                    JSONObject jsonObject = jsonShipping.getJSONObject("response");
                    objAddresses = new ArrayList<Address>();
                    if(jsonObject.getInt("status") == 1){
                        for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                            JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                            Address address = new Address(obj.getString("id"), obj.getString("fname"), obj.getString("lname"), obj.getString("address1"), obj.getString("address2"), obj.getString("street"), obj.getString("city"), obj.getString("address_state"), obj.getString("country"), obj.getString("pincode"), obj.getString("email_id"), obj.getString("contact"), 1);
                            objAddresses.add(address);
                        }
                    }
                    displayShippingData();
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class GetBillingAddresses extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(CheckoutActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("address_type", 2);
                jsonBilling = jsonParser.makeHttpRequestJSON(URLManager.getAddressURL(), "POST", objData);
                Log.d("jsonBilling", objData+"");
                Log.d("jsonBilling", jsonBilling+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonBilling != null){
                    JSONObject jsonObject = jsonBilling.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        objAddresses = new ArrayList<Address>();
                        for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                            JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                            Address address = new Address(obj.getString("id"), obj.getString("fname"), obj.getString("lname"), obj.getString("address1"), obj.getString("address2"), obj.getString("street"), obj.getString("city"), obj.getString("address_state"), obj.getString("country"), obj.getString("pincode"), obj.getString("email_id"), obj.getString("contact"), 1);
                            objAddresses.add(address);
                        }
                        displayBillingData();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(CheckoutActivity.this);
        if(!networkDetails.isEmpty()) {
            new GetShippingAddresses().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(CheckoutActivity.this), Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
        inst = this;
    }
    public static CheckoutActivity instance() {
        return inst;
    }
    public void addressSelected(String addressid, String fulladdress){
        if(address_type == 1){
            ship_full_address = fulladdress;
            tv_full_ship_address.setText(fulladdress);
            selAddressId = addressid;
            reloutAddressList.setVisibility(View.GONE);
            //reloutBillingAddressList.setVisibility(View.VISIBLE);
            address_type = 2;
            Map<String, String> networkDetails = netConnection.getConnectionDetails(CheckoutActivity.this);
            if(!networkDetails.isEmpty()) {
                new GetBillingAddresses().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(CheckoutActivity.this), Toast.LENGTH_LONG).show();
            }
        }else if(address_type ==2){
            tv_full_bill_address.setText(fulladdress);
            bill_full_address = fulladdress;
            selBillingId = addressid;
            reloutBillingAddressList.setVisibility(View.GONE);
            reloutSummary.setVisibility(View.VISIBLE);
        }
    }
}
