package com.vapeempire.app.models;

import javax.xml.transform.dom.DOMLocator;

/**
 * Created by Rahul on 8/13/17
 */

public class OrderItems {
    private String id;
    private String productid;
    private int ingredients;
    private int quantity;
    private String name;
    private String icon;
    private String size;
    private Double original_price;
    private Double discounted_price;

    public OrderItems(){

    }
    public OrderItems(String id, String productid, int ingredients, int quantity, String name,String icon, String size, Double original_price,Double discounted_price){
        this.id = id;
        this.productid = productid;
        this.ingredients = ingredients;
        this.quantity = quantity;
        this.name = name;
        this.icon = icon;
        this.size = size;
        this.original_price = original_price;
        this.discounted_price = discounted_price;
    }

    public String getId(){
        return this.id;
    }
    public String getProductid(){
        return this.productid;
    }
    public String getName(){
        return this.name;
    }
    public String getIcon(){
        return this.icon;
    }
    public String getSize(){
        return this.size;
    }
    public int getIngredients(){
        return this.ingredients;
    }
    public int getQuantity(){
        return this.quantity;
    }
    public Double getOriginal_price(){
        return this.original_price;
    }
    public Double getDiscounted_price(){
        return this.discounted_price;
    }

}
