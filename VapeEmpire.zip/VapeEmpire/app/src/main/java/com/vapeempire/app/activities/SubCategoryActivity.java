package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.SubCategoryGridAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.gridviews.SubCategoryGridView;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Category;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SubCategoryActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private SharedPrefManager sharedPrefManager;
    private SubCategoryActivity fthis;

    private List<Category> categories;
    private SubCategoryGridAdapter subCategoryGridAdapter;
    private SubCategoryGridView subCategoryGridView;

    private String catid, catname;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonSubCat;
    private NetConnection netConnection;
    private int cartCount = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);

        cartCount = sharedPrefManager.getCart_quantity();
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                catname = intent.getExtras().getString("name");
                catid = intent.getExtras().getString("catid");
                toolbar.setTitle(catname);
                setSupportActionBar(toolbar);
                getSupportActionBar().setHomeButtonEnabled(true);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);

                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(SubCategoryActivity.this);
                if(!networkDetails.isEmpty()) {
                    new GettingCategory().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(SubCategoryActivity.this), Toast.LENGTH_LONG).show();
                }

            }
        }catch(Exception ee){
            ee.printStackTrace();
        }
    }



    public void dispCat(){
        subCategoryGridAdapter = new SubCategoryGridAdapter(SubCategoryActivity.this, categories);
        subCategoryGridView = (SubCategoryGridView) findViewById(R.id.gridSubCategory);
        subCategoryGridView.setNumColumns(1);
        subCategoryGridView.setAdapter(subCategoryGridAdapter);
    }

    class GettingCategory extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(SubCategoryActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("id", catid);

                jsonSubCat = jsonParser.makeHttpRequestJSON(URLManager.getSubCategoryURL(), "POST", objData);
                Log.d("jsonSubCat", objData+"");
                Log.d("jsonSubCat", jsonSubCat+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonSubCat != null){
                    JSONObject jsonObject = jsonSubCat.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        categories = new ArrayList<Category>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject category = jsonObject.getJSONArray("data").getJSONObject(i);
                                Category cat = new Category(category.getString("id"), category.getString("name"), category.getString("image"), category.getInt("total_product"), category.getInt("total_child"), category.getInt("total_brand"), category.getString("description"));
                                categories.add(cat);
                            }
                            dispCat();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.findItem(R.id.cartBadge);
        menuItem.setIcon(Helper.buildCounterDrawable(cartCount, R.drawable.ic_cart_w, this));
        return true;
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        cartCount = sharedPrefManager.getCart_quantity();
        invalidateOptionsMenu();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.cartBadge) {
            if(cartCount != 0){
                Intent intent = new Intent(SubCategoryActivity.this, CartActivity.class);
                startActivity(intent);
            }
        }else if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
