package com.vapeempire.app.utils;

/**
 * Created by Rahul on 6/9/17.
 */

public class URLManager {

    private static final String DOMAIN = "http://thenadi.com/";
    private static final String BASE_URL = DOMAIN+"public/rest/";

    public static String getLoginURL(){
        return BASE_URL+"login";
    }
    public static String updateProfileURL(){
        return BASE_URL+"set_user_profile";
    }
    public static String LogoutURL(){
        return BASE_URL+"logout";
    }
    public static String billingInfoURL(){
        return BASE_URL+"set_user_profile";
    }
    public static String createAddressURL(){
        return BASE_URL+"set_user_address";
    }
    public static String getAddressURL(){
        return BASE_URL+"get_user_address";
    }
    public static String deleteAddressURL(){
        return BASE_URL+"delete_address";
    }
    public static String getCategoryURL(){
        return BASE_URL+"get_category_list";
    }
    public static String getSubCategoryURL(){
        return BASE_URL+"get_sub_category_list";
    }
    public static String getBrandURL(){
        return BASE_URL+"get_brand_list";
    }
    public static String getProductListURL(){
        return BASE_URL+"get_product_list";
    }
    public static String getPlayStoreURL(){
        return "http://play.google.com/store/apps/details?id=com.vapeempire.app";
    }
    public static String getPlayStoreMarketURL(){
        return "market://details?id=com.vapeempire.app";
    }
}
