package com.vapeempire.app.utils;

/**
 * Created by Rahul on 6/9/17.
 */

public class URLManager {

    private static final String DOMAIN = "http://thenadi.com/";
    private static final String BASE_URL = DOMAIN+"public/rest/";
    private static final String IMG_BASE_URL = DOMAIN+"public/media/";
    private static final String CAT_IMG_URL = IMG_BASE_URL+"category/";
    private static final String BRAND_IMG_URL = IMG_BASE_URL+"brand/";
    private static final String PRODUCT_IMG_URL = IMG_BASE_URL+"product/";
    private static final String BANNER_IMG_URL = IMG_BASE_URL+"banner/";

    public static String getLoginURL(){
        return BASE_URL+"login";
    }
    public static String updateProfileURL(){
        return BASE_URL+"set_user_profile";
    }
    public static String LogoutURL(){
        return BASE_URL+"logout";
    }
    public static String billingInfoURL(){
        return BASE_URL+"set_user_profile";
    }
    public static String createAddressURL(){
        return BASE_URL+"set_user_address";
    }
    public static String getAddressURL(){
        return BASE_URL+"get_user_address";
    }
    public static String deleteAddressURL(){
        return BASE_URL+"delete_address";
    }
    public static String getCategoryURL(){
        return BASE_URL+"get_category_list";
    }
    public static String getSubCategoryURL(){
        return BASE_URL+"get_sub_category_list";
    }
    public static String getBrandURL(){
        return BASE_URL+"get_brand_list";
    }
    public static String getProductListURL(){
        return BASE_URL+"get_product_list";
    }
    public static String getProductDetailURL(){
        return BASE_URL+"get_product_details";
    }
    public static String getTopProductURL(){
        return BASE_URL+"get_top_sale_product_list";
    }
    public static String getBannerURL(){
        return BASE_URL+"get_banner_list";
    }
    public static String getProductQtyURL(){
        return BASE_URL+"get_product_qty";
    }
    public static String getAddInCartURL(){
        return BASE_URL+"set_mini_cart";
    }
    public static String getMiniCartURL(){
        return BASE_URL+"get_mini_cart";
    }
    public static String getUpdateMiniCartURL(){
        return BASE_URL+"update_mini_cart";
    }
    public static String getDeleteMiniCartURL(){
        return BASE_URL+"delete_mini_cart";
    }
    public static String getApplyCouponURL(){
        return BASE_URL+"set_coupon_code";
    }
    public static String getSetOrderURL(){
        return BASE_URL+"set_order";
    }
    public static String getUpdateOrderURL(){
        return BASE_URL+"update_order";
    }
    public static String getOrderListURL(){
        return BASE_URL+"get_order_list";
    }
    public static String getOrderDetailURL(){
        return BASE_URL+"get_order_details";
    }
    public static String getRelatedProductsURL(){
        return BASE_URL+"get_related_rroduct_list";
    }

    public static String getPlayStoreURL(){
        return "http://play.google.com/store/apps/details?id=com.vapeempire.app";
    }
    public static String getPlayStoreMarketURL(){
        return "market://details?id=com.vapeempire.app";
    }
    public static String getCATIMGURL(String imgurl){
        return CAT_IMG_URL+imgurl;
    }
    public static String getBARNDIMGURL(String imgurl){
        return BRAND_IMG_URL+imgurl;
    }
    public static String getBANNERIMGURL(String imgurl){
        return BANNER_IMG_URL+imgurl;
    }
    public static String getPRODUCTIMGURL(String imgurl){
        return PRODUCT_IMG_URL+imgurl;
    }
}
