package com.vapeempire.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.vapeempire.app.R;

/**
 * Created by Rahul on 29-08-2016.
 */
public class SidebarAdapter extends ArrayAdapter<String> {
    Context context;
    String[] titles;
    int[] icons = {R.drawable.ic_profile, R.drawable.ic_orderhistory, R.drawable.ic_address, R.drawable.ic_billing_address,
            R.drawable.ic_notification, R.drawable.ic_share, R.drawable.ic_call_us, R.drawable.ic_rate_us, R.drawable.ic_about, R.drawable.ic_logout};
    public SidebarAdapter(Context c, String[] menuOptions){
        super(c, R.layout.sidebar_list_layout, R.id.option_txt, menuOptions);
        this.context = c;
        this.titles = menuOptions;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View row = inflater.inflate(R.layout.sidebar_list_layout, parent, false);
        ImageView imgview = (ImageView)row.findViewById(R.id.option_img);
        TextView txtview = (TextView)row.findViewById(R.id.option_txt);
        txtview.setText(titles[position]);
        //imgview.setImageResource(icons[position]);
        return row;
    }
}