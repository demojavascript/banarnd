package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.media.Image;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.AddressListAdapter;
import com.vapeempire.app.adapters.OrderListAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Address;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class AddressActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private static AddressActivity inst;
    private AddressActivity fthis;
    private ArrayList<Address> objAddresses;
    private RecyclerView rvAddress;
    private RecyclerView.Adapter adapterAddressList;
    private RecyclerView.LayoutManager layoutManager;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonAddress, jsonDeleteAddress;
    private NetConnection netConnection;
    private SharedPrefManager sharedPrefManager;
    private int address_type = 1;

    private String deleteid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getAddressActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                address_type = intent.getExtras().getInt("address_type");
                if(address_type == 2){
                    toolbar.setTitle(ActivityTitle.getBillingActivityTitle(this));
                }
            }
        }catch(Exception ee){
            ee.printStackTrace();
        }

    }

    public void displayData(){
        rvAddress = (RecyclerView)findViewById(R.id.recycleview_addresslist);
        layoutManager = new LinearLayoutManager(this);
        rvAddress.setLayoutManager(layoutManager);
        rvAddress.setHasFixedSize(true);
        adapterAddressList = new AddressListAdapter(objAddresses, this, rvAddress);
        rvAddress.setAdapter(adapterAddressList);
    }

    class GetAllAddresses extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(AddressActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("address_type", address_type);
                jsonAddress = jsonParser.makeHttpRequestJSON(URLManager.getAddressURL(), "POST", objData);
                Log.d("jsonAddress", objData+"");
                Log.d("jsonAddress", jsonAddress+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonAddress != null){
                    JSONObject jsonObject = jsonAddress.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        objAddresses = new ArrayList<Address>();
                        for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                            JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                            Address address = new Address(obj.getString("id"), obj.getString("fname"), obj.getString("lname"), obj.getString("address1"), obj.getString("address2"), obj.getString("street"), obj.getString("city"), obj.getString("address_state"), obj.getString("country"), obj.getString("pincode"), obj.getString("email_id"), obj.getString("contact"), address_type);
                            objAddresses.add(address);
                        }
                        displayData();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public void confirmDeleteAddress(String  addressid){
        deleteid = addressid;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(ErrorMessages.getAddressDeleteConfirm(fthis))
                .setCancelable(false)
                .setPositiveButton(ErrorMessages.getAddressDeleteYes(fthis), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        netConnection = new NetConnection();
                        Map<String, String> networkDetails2 = netConnection.getConnectionDetails(AddressActivity.this);
                        if (!networkDetails2.isEmpty()) {
                            new deleteAddresses().execute();
                        } else {
                            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(AddressActivity.this), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton(ErrorMessages.getAddressDeleteNo(fthis), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    class deleteAddresses extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(AddressActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("acces_token", sharedPrefManager.getUserId());
                objData.put("login_by", sharedPrefManager.getLoginType());
                objData.put("name", sharedPrefManager.getUname());
                objData.put("is_login", true);
                objData.put("os", sharedPrefManager.getDeviceOs());
                objData.put("id", deleteid);
                objData.put("address_type", address_type);

                jsonDeleteAddress = jsonParser.makeHttpRequestJSON(URLManager.deleteAddressURL(), "POST", objData);
                Log.d("jsonDeleteAddress", objData+"");
                Log.d("jsonDeleteAddress", jsonDeleteAddress+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonDeleteAddress != null){
                    JSONObject jsonObject = jsonDeleteAddress.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_address, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }else if(id == R.id.action_addAddress){
            Intent intent = new Intent(AddressActivity.this, AddAddressActivity.class);
            intent.putExtra("address_type", address_type);
            startActivity(intent);
        }else{

        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(AddressActivity.this);
        if(!networkDetails.isEmpty()) {
            new GetAllAddresses().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(AddressActivity.this), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
        inst = this;
    }
    public static AddressActivity instance() {
        return inst;
    }
}
