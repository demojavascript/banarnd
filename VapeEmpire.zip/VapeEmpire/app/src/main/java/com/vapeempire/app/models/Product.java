package com.vapeempire.app.models;

import java.util.ArrayList;

import javax.xml.validation.Validator;

/**
 * Created by Rahul on 6/18/17.
 */

public class Product {
    private String productId;
    private String productName;
    private String productIcon;
    private Double productPrice;
    private String productDesc;
    private Double discountedPrice;
    private String productsku;
    private String metakey;
    private String metaDesc;
    private String catid;
    private String brandid;
    private String brandname;
    private String catname;
    private String size;
    private ArrayList<ProductVariant> productVariant;

    public Product(){

    }
    public Product(String productId, String productName, String productIcon, Double productPrice, String productDesc, Double discountedPrice, String productsku, String metakey,String metaDesc, String catid, String brandid, String brandname, String catname, String size, ArrayList<ProductVariant> productVariant){
        this.productId = productId;
        this.productName = productName;
        this.productIcon = productIcon;
        this.productPrice = productPrice;
        this.productDesc = productDesc;
        this.discountedPrice = discountedPrice;
        this.productsku = productsku;
        this.metakey = metakey;
        this.metaDesc = metaDesc;
        this.catid = catid;
        this.brandid = brandid;
        this.brandname = brandname;
        this.catname = catname;
        this.size = size;
        this.productVariant = productVariant;
    }
    public void setProductId(String productId){
        this.productId = productId;
    }
    public void setProductName(String productName){
        this.productName = productName;
    }
    public void setProductIcon(String productIcon){
        this.productIcon = productIcon;
    }
    public void setProductPrice(Double productPrice){
        this.productPrice = productPrice;
    }
    public void setSize(String size){
        this.size = size;
    }
    public String getProductId(){
        return this.productId;
    }
    public String getProductName(){
        return this.productName;
    }
    public String getProductIcon(){
        return this.productIcon;
    }
    public Double getProductPrice(){
        return this.productPrice;
    }
    public Double getDiscountedPrice(){
        return this.discountedPrice;
    }
    public String getProductDesc(){
        return this.productDesc;
    }
    public String getProductsku(){
        return this.productsku;
    }
    public String getMetakey(){
        return this.metakey;
    }
    public String getMetaDesc(){
        return this.metaDesc;
    }
    public String getCatid(){
        return this.catid;
    }
    public String getBrandid(){
        return this.brandid;
    }
    public String getBrandname(){
        return this.brandname;
    }
    public String getCatname(){
        return this.catname;
    }
    public String getSize(){
        return this.size;
    }
    public ArrayList<ProductVariant> getProductVariant(){
        return this.productVariant;
    }
}
