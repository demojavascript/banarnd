package com.vapeempire.app.models;

import java.io.Serializable;

/**
 * Created by Rahul on 6/27/17.
 */

public class Address implements Serializable {
    private String id;
    private String fname;
    private String lname;
    private String address1;
    private String address2;
    private String street;
    private String city;
    private String state;
    private String country;
    private String pincode;
    private String emailid;
    private String mobileno;
    private int type;

    public Address(){

    }
    public Address(String id, String fname, String lname, String address1, String address2, String street, String city, String state, String country, String pincode, String emailid, String mobileno, int type){
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.address1 = address1;
        this.address2 = address2;
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
        this.pincode = pincode;
        this.emailid = emailid;
        this.mobileno = mobileno;
        this.type = type;
    }

    public void setId(String id){
        this.id = id;
    }
    public void setFname(String fname){
        this.fname = fname;
    }
    public void setLname(String lname){
        this.lname = lname;
    }
    public void setAddress1(String address1){
        this.address1 = address2;
    }
    public void setAddress2(String address2){
        this.address1 = address2;
    }
    public void setStreet(String street){
        this.street = street;
    }
    public void setCity(String city){
        this.city = city;
    }
    public void setState(String state){
        this.state = state;
    }
    public void setPincode(String pincode){
        this.pincode = pincode;
    }
    public void setEmailid(String emailid){
        this.emailid = emailid;
    }
    public void setMobileno(String mobileno){
        this.mobileno = mobileno;
    }
    public void setType(int type){this.type = type;}

    public String getId(){
        return this.id;
    }
    public String getFname(){
        return this.fname;
    }
    public String getLname(){return this.lname;}
    public String getAddress1(){
        return this.address1;
    }
    public String getAddress2(){
        return this.address2;
    }
    public String getStreet(){
        return this.street;
    }
    public String getCity(){
        return this.city;
    }
    public String getState(){
        return this.state;
    }
    public String getCountry(){return this.country;}
    public String getPincode(){return this.pincode;}
    public String getEmailid(){return this.emailid;}
    public String getMobileno(){return this.mobileno;}
    public int getType(){return this.type;}
}
