package com.vapeempire.app.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.vapeempire.app.R;
import com.vapeempire.app.activities.CartActivity;
import com.vapeempire.app.models.Cart;
import com.vapeempire.app.utils.URLManager;

import java.util.ArrayList;

/**
 * Created by Rahul on 8/6/17.
 */

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
    ArrayList<Cart> cartItems = new ArrayList<Cart>();
    Context ctx;
    RecyclerView resourceIdd;
    public CartAdapter(ArrayList<Cart> cartItems, Context ctx, RecyclerView resourceIdd){
        this.cartItems = cartItems;
        this.ctx = ctx;
        this.resourceIdd = resourceIdd;
    }
    @Override
    public CartViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_cart_column, parent, false);
        CartViewHolder contactViewHolder = new CartViewHolder(view, ctx, cartItems, resourceIdd);
        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(CartViewHolder holder, int position) {
        Cart objCart = cartItems.get(position);
        holder.tvProductName.setText(objCart.getName());
        holder.tv_ProductMrp.setText(objCart.getDiscounted_price()+"");
        holder.tvProductQty.setText(objCart.getQty()+"");
        holder.tv_ProducQty2.setText(objCart.getQty()+"");
        Picasso.with(ctx).load(URLManager.getPRODUCTIMGURL(objCart.getIcon())).into(holder.img_ProductPic);
    }
    @Override
    public int getItemCount() {
        return cartItems.size();
    }
    public static class CartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvProductName, tvProductQty, tv_ProducQty2, tv_ProductMrp;
        CardView cardview_row_cart;
        Context ctx;
        ImageView btn_Add, btn_Sub, img_ProductPic;
        ArrayList<Cart> carts;
        public CartViewHolder(View view, Context ctx, ArrayList<Cart> carts, RecyclerView resourceIdd){
            super(view);
            this.carts = carts;
            this.ctx = ctx;
            this.tvProductName = (TextView)view.findViewById(R.id.tvProductName);
            this.tvProductQty = (TextView)view.findViewById(R.id.tvProductQty);
            this.tv_ProducQty2 = (TextView)view.findViewById(R.id.tv_ProducQty2);
            this.tv_ProductMrp = (TextView)view.findViewById(R.id.tv_ProductMrp);
            this.btn_Add = (ImageView)view.findViewById(R.id.btn_Add);
            this.btn_Add.setOnClickListener(this);
            this.btn_Sub = (ImageView)view.findViewById(R.id.btn_Sub);
            this.btn_Sub.setOnClickListener(this);
            this.img_ProductPic = (ImageView)view.findViewById(R.id.img_ProductPic);
        }

        @Override
        public void onClick(View v) {
            Cart cart = this.carts.get(getAdapterPosition());
            int nowQty = Integer.parseInt(this.tv_ProducQty2.getText().toString());
            CartActivity inst1 = CartActivity.instance();
            switch(v.getId()){
                case R.id.btn_Add:
                    nowQty = nowQty + 1;
                    this.tv_ProducQty2.setText(nowQty+"");
                    inst1.updateCart(cart.getProductId(), cart.getIngredients(), nowQty, cart.getId());
                    break;
                case R.id.btn_Sub:
                    if(nowQty > 0){
                        nowQty = nowQty - 1;
                        this.tv_ProducQty2.setText(nowQty+"");
                        if(nowQty == 0){
                            inst1.deleteCart(cart.getProductId(), cart.getIngredients());
                        }else{
                            inst1.updateCart(cart.getProductId(), cart.getIngredients(), nowQty, cart.getId());
                        }
                    }
                    break;
            }
        }
    }
}