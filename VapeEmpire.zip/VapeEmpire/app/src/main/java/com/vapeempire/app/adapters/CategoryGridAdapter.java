package com.vapeempire.app.adapters;

/**
 * Created by Rahul on 10-01-2016.
 */

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.vapeempire.app.R;
import com.vapeempire.app.activities.BrandListActivity;
import com.vapeempire.app.activities.ProductListActivity;
import com.vapeempire.app.activities.SubCategoryActivity;
import com.vapeempire.app.models.Category;

import java.util.List;

public class CategoryGridAdapter extends BaseAdapter {
    private Context mContext;
    private List<Category> categories;

    @Override
    public int getCount() {
        return categories.size();
    }

    public CategoryGridAdapter(Context c, List<Category> categories) {
        mContext = c;
        this.categories = categories;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View grid;
        final LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            grid = new View(mContext);
            grid = inflater.inflate(R.layout.grid_category_column, null);

            final Category category = categories.get(position);
            TextView tvdealname = (TextView) grid.findViewById(R.id.grid_category_name);
            ImageView imgdealimg = (ImageView) grid.findViewById(R.id.grid_category_image);
            final CardView cardView = (CardView)grid.findViewById(R.id.cardview_row_category);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent;
                    if(category.getTotal_child() < 1) {
                        intent = new Intent(mContext, SubCategoryActivity.class);
                    }else{
                        intent = new Intent(mContext, BrandListActivity.class);
                    }
                    intent.putExtra("catid", category.getCatid());
                    intent.putExtra("name", category.getTitle());
                    mContext.startActivity(intent);
                }
            });
            tvdealname.setText(category.getTitle());
            //new ImageDownloaderTask(imgdealimg).execute(currdeal.getDealIcon());
        } else {
            grid = (View) convertView;
        }
        return grid;
    }
}