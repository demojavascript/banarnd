package com.vapeempire.app.models;

import java.io.Serializable;

/**
 * Created by Rahul on 6/18/17.
 */

public class Order implements Serializable {
    private String orderId;
    private String orderDate;
    private int orderStatus;
    private Double orderAmount;
    private int qty;
    public Order(){

    }
    public Order(String orderId, String orderDate, int orderStatus, Double orderAmount){
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.orderStatus = orderStatus;
    }
    public Order(String orderId, String orderDate, int orderStatus, Double orderAmount, int qty){
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.orderStatus = orderStatus;
        this.qty = qty;
    }
    public void setOrderId(String orderId){
        this.orderId = orderId;
    }
    public void setOrderDate(String orderDate){
        this.orderDate = orderDate;
    }
    public void setOrderStatus(int orderStatus){
        this.orderStatus = orderStatus;
    }
    public void setOrderAmount(Double orderAmount){
        this.orderAmount = orderAmount;
    }
    public String getOrderId(){
        return this.orderId;
    }
    public String getOrderDate(){
        return this.orderDate;
    }
    public int getOrderStatus(){
        return this.orderStatus;
    }
    public Double getOrderAmount(){
        return this.orderAmount;
    }
    public int getQty(){return this.qty;}
}
