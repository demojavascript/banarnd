package com.vapeempire.app.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Rahul on 6/27/17.
 */

public class Helper {
    private static String[] MONTHS_NAME = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
    public static String getDob(int year, int month, int date){
        return date+" "+MONTHS_NAME[month-1]+" "+year;
    }
    public static String getCurrentDate(){
        Date dt = new Date();
        return dt.getYear()+"-" + (dt.getMonth()+1)+"-"+String.valueOf((Calendar.getInstance()).get(Calendar.DAY_OF_MONTH));
    }
    public static boolean validateEmailAddress(String emailAddress){
        String  expression="^[\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = emailAddress;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }
    public static boolean validatePincode(String pincode){
        return pincode.matches("[0-9]{6}");
    }
}
