package com.vapeempire.app.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.vapeempire.app.R;

import java.util.Calendar;
import java.util.Date;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Rahul on 6/27/17.
 */

public class Helper {
    private static String[] MONTHS_NAME = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
    private static boolean SHOW_TOAST_ON_ERROR = false;
    public static boolean isShowCommonErrorToast(){
        return SHOW_TOAST_ON_ERROR;
    }
    public static String getDob(int year, int month, int date){
        return date+" "+MONTHS_NAME[month-1]+" "+year;
    }
    public static String getCurrentDate(){
        Date dt = new Date();
        return dt.getYear()+"-" + (dt.getMonth()+1)+"-"+String.valueOf((Calendar.getInstance()).get(Calendar.DAY_OF_MONTH));
    }
    public static boolean validateEmailAddress(String emailAddress){
        String  expression="^[\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = emailAddress;
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        return matcher.matches();
    }
    public static String createTransactionID() throws Exception{
        return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
    }

    public static String orderStatus(int num){
        String status = "";
        switch(num){
            case 1:
                status = "Pending";
                break;
            case 2:
                status = "Placed";
                break;
            case 3:
                status = "Shipped";
                break;
            case 4:
                status = "Cancel";
                break;
            case 5:
                status = "Complete";
                break;
        }
        return status;
    }

    public static Drawable buildCounterDrawable(int count, int backgroundImageId, Context ctx) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View view = inflater.inflate(R.layout.counter_menuitem_layout, null);
        view.setBackgroundResource(backgroundImageId);

        if (count == 0) {
            View counterTextPanel = view.findViewById(R.id.counterValuePanel);
            counterTextPanel.setVisibility(View.GONE);
        } else {
            TextView textView = (TextView) view.findViewById(R.id.count);
            textView.setText("" + count);
        }

        view.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        view.setDrawingCacheEnabled(true);
        view.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);

        return new BitmapDrawable(ctx.getResources(), bitmap);
    }

    public static boolean validatePincode(String pincode){
        return pincode.matches("[0-9]{6}");
    }
}
