package com.vapeempire.app.models;

/**
 * Created by Rahul on 8/6/17.
 */

public class Cart {
    private String id;
    private String productId;
    private String name;
    private String user_id;
    private int ingredients;
    private int qty;
    private String icon;
    private String size;
    private Double original_price;
    private Double discounted_price;
    public Cart(){

    }
    public Cart(String id, String productId, String name, String user_id, int ingredients, int qty, String icon, String size, Double original_price, Double discounted_price){
        this.id = id;
        this.productId = productId;
        this.name = name;
        this.user_id = user_id;
        this.ingredients = ingredients;
        this.qty = qty;
        this.icon = icon;
        this.size = size;
        this.original_price = original_price;
        this.discounted_price = discounted_price;
    }

    public void setId(String id){
        this.id = id;
    }
    public void setProductId(String productId){
        this.productId = productId;
    }
    public void setName(String name) {this.name = name;}
    public void setUser_id(String user_id){this.user_id = user_id;}
    public void setIngredients(int ingredients){this.ingredients = ingredients;}
    public void setQty(int qty){this.qty = qty;}
    public void setIcon(String icon){this.icon = icon;}
    public void setSize(String  size){this.size = size;}
    public void setOriginal_price(Double original_price){this.original_price = original_price;}
    public void setDiscounted_price(Double discounted_price){this.discounted_price = discounted_price;}

    public String getId(){
        return this.id;
    }
    public String getProductId(){
        return this.productId;
    }
    public String getName(){
        return this.name;
    }
    public String getUser_id(){
        return this.user_id;
    }
    public int getIngredients(){
        return this.ingredients;
    }
    public int getQty(){
        return this.qty;
    }
    public String getIcon(){
        return this.icon;
    }
    public String getSize(){
        return this.size;
    }
    public Double getOriginal_price(){
        return this.original_price;
    }
    public Double getDiscounted_price(){
        return this.discounted_price;
    }

}
