package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.models.OrderDetail;
import com.vapeempire.app.models.OrderItems;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class OrderDetailActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private OrderDetailActivity fthis;
    private OrderDetail objOrder;
    private String invoiceid;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;
    private SharedPrefManager sharedPrefManager;
    private RelativeLayout reloutDetail;
    private LinearLayout lout_cancel;
    private TableLayout tab_detail;
    private LinearLayout loutcoupon1, loutcoupon2;
    private TextView tv_invoiceid, tv_grandtotal, tv_orderstatus, tv_qty, tv_orderdate, tv_couponcode, tv_couponamount, tv_shippingamount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);

        loutcoupon2 = (LinearLayout)findViewById(R.id.loutcoupon2);
        loutcoupon1 = (LinearLayout)findViewById(R.id.loutcoupon1);

        tv_couponcode = (TextView)findViewById(R.id.tv_couponcode);
        tv_couponamount = (TextView)findViewById(R.id.tv_couponamount);
        tv_shippingamount = (TextView)findViewById(R.id.tv_shippingamount);
        tab_detail = (TableLayout)findViewById(R.id.tab_detail);
        tv_invoiceid = (TextView)findViewById(R.id.tv_invoiceid);
        tv_grandtotal = (TextView)findViewById(R.id.tv_grandtotal);
        tv_orderdate = (TextView)findViewById(R.id.tv_orderdate);
        tv_orderstatus = (TextView)findViewById(R.id.tv_orderstatus);
        tv_qty = (TextView)findViewById(R.id.tv_qty);
        reloutDetail = (RelativeLayout)findViewById(R.id.reloutDetail);
        lout_cancel = (LinearLayout)findViewById(R.id.lout_cancel);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(!bundle.isEmpty()){
            invoiceid = intent.getExtras().getString("invoiceid");
            toolbar.setTitle("Order - "+invoiceid);
            setSupportActionBar(toolbar);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            netConnection = new NetConnection();
            Map<String, String> networkDetails = netConnection.getConnectionDetails(OrderDetailActivity.this);
            if(!networkDetails.isEmpty()) {
                new GetOrderDetail().execute();
            }else{
                Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(OrderDetailActivity.this), Toast.LENGTH_LONG).show();
            }

        }
    }

    public void displayData(){
        reloutDetail.setVisibility(View.VISIBLE);
        tv_invoiceid.setText(objOrder.getInvoiceid());
        tv_grandtotal.setText(objOrder.getTotalAmount()+"");
        tv_orderstatus.setText(Helper.orderStatus(objOrder.getOrderstatus()));
        tv_orderdate.setText(objOrder.getOrderdate()+"");
        tv_qty.setText(objOrder.getQuantity()+"");
        if(objOrder.getCouponId() != null && objOrder.getCouponId().length() > 0){
            loutcoupon1.setVisibility(View.VISIBLE);
            loutcoupon2.setVisibility(View.VISIBLE);
            tv_couponcode.setText(objOrder.getCouponId());
            tv_couponamount.setText(objOrder.getDiscountedAmount()+"");
        }
        if(objOrder.getOrderstatus() == 0 || objOrder.getOrderstatus() == 1){
            lout_cancel.setVisibility(View.VISIBLE);
        }
        tv_shippingamount.setText(objOrder.getShippingAmount()+"");
        for (int i = 0; i < objOrder.getOrderItems().size(); i++) {
            OrderItems item = objOrder.getOrderItems().get(i);
            TableRow tbrow = new TableRow(this);
            tbrow.setOrientation(TableRow.HORIZONTAL);

            TextView t1v = new TextView(this);
            t1v.setText(item.getName());
            t1v.setTextAppearance(this, R.style.tvTableColumn);
            t1v.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
            t1v.setLayoutParams(params);
            tbrow.addView(t1v);

            LinearLayout linouttv2 = (LinearLayout)getLayoutInflater().inflate(R.layout.table_column_view, null);
            TextView t2v = (TextView) linouttv2.findViewById(R.id.tv_textview);
            t2v.setText(item.getQuantity()+"");
            t2v.setGravity(Gravity.CENTER| Gravity.CENTER_VERTICAL);
            t2v.setWidth(30);
            linouttv2.setGravity(Gravity.CENTER| Gravity.CENTER_VERTICAL);
            tbrow.addView(linouttv2);

            LinearLayout linouttv3 = (LinearLayout)getLayoutInflater().inflate(R.layout.table_column_view, null);
            TextView t3v = (TextView) linouttv3.findViewById(R.id.tv_textview);
            TextView t33v = (TextView) linouttv3.findViewById(R.id.tv_rsdrawable);
            t33v.setVisibility(View.VISIBLE);
            t33v.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            t3v.setText(item.getDiscounted_price()+"");
            t3v.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            linouttv3.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            tbrow.addView(linouttv3);

            LinearLayout linouttv4 = (LinearLayout)getLayoutInflater().inflate(R.layout.table_column_view, null);
            TextView t4v = (TextView) linouttv4.findViewById(R.id.tv_textview);
            TextView t44v = (TextView) linouttv4.findViewById(R.id.tv_rsdrawable);
            t44v.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            t44v.setVisibility(View.VISIBLE);
            t4v.setText(item.getDiscounted_price()*item.getQuantity()+"");
            t4v.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            linouttv4.setGravity(Gravity.RIGHT| Gravity.CENTER_VERTICAL);
            tbrow.addView(linouttv4);

            tab_detail.addView(tbrow);
        }

    }

    class GetOrderDetail extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(OrderDetailActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("invoice_id", invoiceid);
                json = jsonParser.makeHttpRequestJSON(URLManager.getOrderDetailURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONObject("data") != null){
                            JSONObject adata = jsonObject.getJSONObject("data");
                            ArrayList<OrderItems> items = new ArrayList<OrderItems>();
                            for(int i=0;i<jsonObject.getJSONObject("data").getJSONArray("item_list").length();i++){
                                JSONObject objh = jsonObject.getJSONObject("data").getJSONArray("item_list").getJSONObject(i);
                                OrderItems item = new OrderItems(objh.getString("id"), objh.getString("product_id"), Integer.parseInt(objh.getString("ingredients")), Integer.parseInt(objh.getString("qty")), objh.getString("name"), objh.getString("image"), objh.getString("product_size"), Double.parseDouble(objh.getString("original_price")), Double.parseDouble(objh.getString("discounted_price")));
                                items.add(item);
                            }
                            objOrder = new OrderDetail(adata.getString("invoice_id"), adata.getString("created_date"), Double.parseDouble(adata.getString("grand_total")), adata.getString("coupon_id"), Double.parseDouble(adata.getString("discount_amount")), Double.parseDouble(adata.getString("shipping_amount")), Integer.parseInt(adata.getString("qty")), Integer.parseInt(adata.getString("order_status")), Double.parseDouble(adata.getString("refund_amount")), Integer.parseInt(adata.getString("payment_type")),  items);
                            displayData();
                        }else{
                            Toast.makeText(getApplicationContext(), ErrorMessages.getNoOrder(fthis), Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
