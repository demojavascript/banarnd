package com.vapeempire.app.utils;

import android.content.Context;
import android.content.res.Resources;

import com.vapeempire.app.R;

/**
 * Created by Rahul on 6/11/17.
 */

public class ActivityTitle {
    public static String getAddressActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.addressActivityTitle);
    }
    public static String getAddAddressActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.addAddressActivityTitle);
    }
    public static String getEditAddressActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.editAddressActivityTitle);
    }
    public static String getBrandActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getCartActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.cartActivityTitle);
    }
    public static String getCheckoutActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.checkoutActivityTitle);
    }
    public static String getContentActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getNotificationActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.notificationActivityTitle);
    }
    public static String getOrdersActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.orderActivityTitle);
    }
    public static String getOrderDetailActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getOrderSuccessActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.orderSuccessActivityTitle);
    }
    public static String getProductListActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getProductDetailActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getProfileActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.profileActivityTitle);
    }
    public static String getOrderPlaceActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.orderPlaceActivityTitle);
    }
    public static String getSubCategoryActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.brandActivityTitle);
    }
    public static String getBillingActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.billingActivityTitle);
    }
    public static String getAddBillingActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.addBillingActivityTitle);
    }
    public static String getEditBillingActivityTitle(Context ctx){
        return getResources(ctx).getString(R.string.editBillingActivityTitle);
    }
    private static Resources getResources(Context ctx){
        return ctx.getResources();
    }
}
