package com.vapeempire.app.adapters;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.vapeempire.app.R;
import com.vapeempire.app.models.CNotification;

import java.util.ArrayList;

/**
 * Created by Rahul on 8/20/17.
 */

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationListViewHolder> {
    ArrayList<CNotification> notifications = new ArrayList<CNotification>();
    Context ctx;
    RecyclerView resourceIdd;
    private String[] state;
    public NotificationAdapter(ArrayList<CNotification> addresses, Context ctx, RecyclerView resourceIdd){
        this.notifications = notifications;
        this.ctx = ctx;
        this.resourceIdd = resourceIdd;
        Resources objres = ctx.getResources();
        state = objres.getStringArray(R.array.allState);
    }
    @Override
    public NotificationListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_notification, parent, false);
        NotificationListViewHolder contactViewHolder = new NotificationListViewHolder(view, ctx, notifications, resourceIdd);
        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(NotificationListViewHolder holder, int position) {
        CNotification objNotify = notifications.get(position);
        holder.tv_title.setText(objNotify.getTitle());
        holder.tv_desc.setText(objNotify.getDesc());
        holder.tv_date.setText(objNotify.getDate());

    }
    @Override
    public int getItemCount() {
        return notifications.size();
    }
    public static class NotificationListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tv_title, tv_desc, tv_date;
        CardView cardview_row_notify;
        Context ctx;
        ImageView img_notification_icon, img_bigimg;
        ArrayList<CNotification> notifications;
        public NotificationListViewHolder(View view, Context ctx, ArrayList<CNotification> notifications, RecyclerView resourceIdd){
            super(view);
            this.ctx = ctx;
            this.notifications = notifications;
            this.img_bigimg = (ImageView)view.findViewById(R.id.img_bigimg);
            this.img_notification_icon = (ImageView)view.findViewById(R.id.img_notification_icon);
            this.tv_title = (TextView)view.findViewById(R.id.tv_title);
            this.tv_desc = (TextView)view.findViewById(R.id.tv_desc);
            this.tv_date = (TextView)view.findViewById(R.id.tv_date);
        }

        @Override
        public void onClick(View v) {
            int pos = getAdapterPosition();
        }
    }
}
