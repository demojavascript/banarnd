package com.vapeempire.app.models;


import java.util.ArrayList;

public class OrderDetail {
    private String invoiceid;
    private String orderdate;
    private Double totalAmount;
    private String couponId;
    private Double discountedAmount;
    private Double shippingAmount;
    private int quantity;
    private int orderstatus;
    private Double refundamount;
    private int paymenttype;
    private ArrayList<OrderItems> orderItems;

    public OrderDetail(){

    }
    public OrderDetail(String invoiceid, String orderdate, Double totalAmount, String couponId, Double discountedAmount, Double shippingAmount, int quantity, int orderstatus, Double refundamount, int paymenttype, ArrayList<OrderItems> orderItems){
        this.invoiceid = invoiceid;
        this.orderdate = orderdate;
        this.totalAmount = totalAmount;
        this.couponId = couponId;
        this.discountedAmount = discountedAmount;
        this.shippingAmount = shippingAmount;
        this.quantity = quantity;
        this.orderstatus = orderstatus;
        this.refundamount = refundamount;
        this.paymenttype = paymenttype;
        this.orderItems = orderItems;
    }

    public String getInvoiceid(){
        return this.invoiceid;
    }
    public String getOrderdate(){
        return this.orderdate;
    }
    public String getCouponId(){
        return this.couponId;
    }
    public Double getTotalAmount(){
        return this.totalAmount;
    }
    public Double getDiscountedAmount(){
        return this.discountedAmount;
    }
    public Double getShippingAmount(){
        return this.shippingAmount;
    }
    public Double getRefundamount(){
        return this.refundamount;
    }
    public int getQuantity(){
        return this.quantity;
    }
    public int getOrderstatus(){
        return this.orderstatus;
    }
    public int getPaymenttype(){
        return this.paymenttype;
    }
    public ArrayList<OrderItems> getOrderItems(){
        return this.orderItems;
    }
}
