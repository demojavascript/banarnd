package com.vapeempire.app.models;

/**
 * Created by Rahul on 6/18/17.
 */

public class Brand {
    /*
    *"total_product": "1",
                "total_category": "1",
    * */
    private String brandId;
    private String brandName;
    private String brandIcon;
    private String brandDesc;
    private String catId;
    private int total_product;

    public Brand(){

    }
    public Brand(String brandId, String brandName, String brandIcon, String brandDesc, String catId, int total_product){
        this.brandId = brandId;
        this.brandName = brandName;
        this.brandIcon = brandIcon;
        this.brandDesc = brandDesc;
        this.catId = catId;
        this.total_product = total_product;
    }
    public void setBrandId(String brandId){
        this.brandId = brandId;
    }
    public void setBrandName(String brandName){
        this.brandName = brandName;
    }
    public void setBrandIcon(String brandIcon){
        this.brandIcon = brandIcon;
    }
    public void setBrandDesc(String brandDesc){
        this.brandDesc = brandDesc;
    }
    public void setCatId(String catId){
        this.catId = catId;
    }
    public void setTotal_product(int total_product){
        this.total_product = total_product;
    }

    public String getBrandId(){
        return this.brandId;
    }
    public String getBrandName(){
        return this.brandName;
    }
    public String getBrandIcon(){
        return this.brandIcon;
    }
    public String getBrandDesc(){
        return this.brandDesc;
    }
    public String getCatId(){
        return this.catId;
    }
    public int getTotal_product(){
        return this.total_product;
    }
}
