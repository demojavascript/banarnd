package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.ProductGridAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.gridviews.ProductGridView;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Category;
import com.vapeempire.app.models.Product;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ProductListActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private SharedPrefManager sharedPrefManager;
    private ProductListActivity fthis;
    private String brandid, brandname, catid;
    private ProductGridAdapter productGridAdapter;
    private ProductGridView productGridView;
    private List<Product> products;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonProducts;
    private NetConnection netConnection;
    private int cartCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        cartCount = sharedPrefManager.getCart_quantity();
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                brandname = intent.getExtras().getString("brandname");
                brandid = intent.getExtras().getString("brandid");
                catid = intent.getExtras().getString("catid");
                toolbar.setTitle(brandname);
                setSupportActionBar(toolbar);
                getSupportActionBar().setHomeButtonEnabled(true);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);

                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(ProductListActivity.this);
                if(!networkDetails.isEmpty()) {
                    new GettingProducts().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(ProductListActivity.this), Toast.LENGTH_LONG).show();
                }

            }
        }catch(Exception ee){
            ee.printStackTrace();
        }
    }
    public void dispProduct(){
        productGridAdapter = new ProductGridAdapter(this, products);
        productGridView = (ProductGridView) findViewById(R.id.gridProduct);
        productGridView.setNumColumns(2);
        productGridView.setAdapter(productGridAdapter);
    }


    class GettingProducts extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProductListActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("category_id", catid);
                objData.put("brand_id", brandid);

                jsonProducts = jsonParser.makeHttpRequestJSON(URLManager.getProductListURL(), "POST", objData);
                Log.d("jsonProducts", objData+"");
                Log.d("jsonProducts", jsonProducts+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonProducts != null){
                    JSONObject jsonObject = jsonProducts.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        products = new ArrayList<Product>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject product = jsonObject.getJSONArray("data").getJSONObject(i);
                                Product obj = new Product(product.getString("id"), product.getString("name"), product.getString("image"), product.getDouble("original_price"), product.getString("description"), product.getDouble("discounted_price"), product.getString("sku"), product.getString("meta_key"), product.getString("meta_description"), product.getString("category_id"), product.getString("brand_id"), product.getString("brand_name"), product.getString("category_name"), product.getString("product_size"), null);
                                products.add(obj);
                            }
                            dispProduct();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }else if(id == R.id.action_addAddress){
            Intent intent = new Intent(ProductListActivity.this, CartActivity.class);
            startActivity(intent);
        }else if (id == R.id.cartBadge) {
            if(cartCount != 0){
                Intent intent = new Intent(ProductListActivity.this, CartActivity.class);
                startActivity(intent);
            }
        }else{

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.findItem(R.id.cartBadge);
        menuItem.setIcon(Helper.buildCounterDrawable(cartCount, R.drawable.ic_cart_w, this));
        return true;
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        cartCount = sharedPrefManager.getCart_quantity();
        invalidateOptionsMenu();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
