package com.vapeempire.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.vapeempire.app.R;
import com.vapeempire.app.activities.OrderDetailActivity;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.utils.Helper;

import java.util.ArrayList;

/**
 * Created by Rahul on 16-08-2016.
 */
public class OrderListAdapter extends RecyclerView.Adapter<OrderListAdapter.OrderListViewHolder> {
    ArrayList<Order> orders = new ArrayList<Order>();
    Context ctx;
    RecyclerView resourceIdd;
    public OrderListAdapter(ArrayList<Order> orders, Context ctx, RecyclerView resourceIdd){
        this.orders = orders;
        this.ctx = ctx;
        this.resourceIdd = resourceIdd;
    }
    @Override
    public OrderListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderlist_list_column, parent, false);
        OrderListViewHolder contactViewHolder = new OrderListViewHolder(view, ctx, orders, resourceIdd);
        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(OrderListViewHolder holder, int position) {
        Order objOrder = orders.get(position);
        holder.tvOrderNo.setText(objOrder.getOrderId());
        holder.tvOrderAmount.setText(objOrder.getOrderAmount()+"");
        holder.tvOrderDate.setText(objOrder.getOrderDate());
        holder.tvOrderStatus.setText(Helper.orderStatus(objOrder.getOrderStatus()));
        holder.tvitemcount.setText(objOrder.getQty()+"");
    }
    @Override
    public int getItemCount() {
        return orders.size();
    }
    public static class OrderListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvOrderNo, tvOrderAmount, tvOrderDate, tvOrderStatus, tvitemcount;
        CardView cardview_row_order;
        Context ctx;
        ArrayList<Order> orders;
        public OrderListViewHolder(View view, Context ctx, ArrayList<Order> orders, RecyclerView resourceIdd){
            super(view);
            this.orders = orders;
            this.ctx = ctx;
            tvOrderNo = (TextView)view.findViewById(R.id.tvOrderNo);
            tvOrderAmount = (TextView)view.findViewById(R.id.tvOrderAmount);
            tvOrderDate = (TextView)view.findViewById(R.id.tvOrderDate);
            tvOrderStatus = (TextView)view.findViewById(R.id.tvOrderStatus);
            tvitemcount = (TextView)view.findViewById(R.id.tvitemcount);
            cardview_row_order = (CardView)view.findViewById(R.id.cardview_row_order);
            cardview_row_order.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(ctx, OrderDetailActivity.class);
            intent.putExtra("invoiceid", orders.get(getAdapterPosition()).getOrderId());
            ctx.startActivity(intent);
        }
    }
}
