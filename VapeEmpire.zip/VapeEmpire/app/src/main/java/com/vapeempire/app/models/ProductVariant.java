package com.vapeempire.app.models;

/**
 * Created by Rahul on 7/23/17.
 */

public class ProductVariant {
    private String id;
    private int qty;
    private Double original_price;
    private Double discounted_price;
    private String size;
    private int flag;

    public ProductVariant(){

    }
    public ProductVariant(String id, int qty, Double original_price, Double discounted_price, String size, int flag){
        this.id = id;
        this.qty = qty;
        this.original_price = original_price;
        this.discounted_price = discounted_price;
        this.size = size;
        this.flag = flag;
    }

    public void setId(String id){
        this.id = id;
    }
    public void setQty(int qty){
        this.qty = qty;
    }
    public void setOriginal_price(Double original_price){
        this.original_price = original_price;
    }
    public void setDiscounted_price(Double discounted_price){
        this.discounted_price = discounted_price;
    }
    public void setFlag(int flag){
        this.flag = flag;
    }

    public String getId(){
        return this.id;
    }
    public int getQty(){
        return this.qty;
    }
    public Double getOriginal_price(){
        return this.original_price;
    }
    public Double getDiscounted_price(){
        return this.discounted_price;
    }
    public String getSize(){
        return this.size;
    }
    public int getFlag(){
        return this.flag;
    }
}
