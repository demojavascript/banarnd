package com.vapeempire.app.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.OrderListAdapter;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.utils.ActivityTitle;

import java.util.ArrayList;

public class OrderListActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private OrderListActivity fthis;

    private ArrayList<Order> objOrders;
    private RecyclerView rvOrder;
    private RecyclerView.Adapter adapterOrderList;
    private RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getOrdersActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        objOrders = new ArrayList<Order>();
        for(int h=0;h<10;h++){
            Order order = new Order("34534"+h, h+" July 2018", 1, 2300.7);
            objOrders.add(order);
        }
        rvOrder = (RecyclerView)findViewById(R.id.recycleview_orderlist);
        layoutManager = new LinearLayoutManager(this);
        rvOrder.setLayoutManager(layoutManager);
        rvOrder.setHasFixedSize(true);
        adapterOrderList = new OrderListAdapter(objOrders, this, rvOrder);
        rvOrder.setAdapter(adapterOrderList);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

}
