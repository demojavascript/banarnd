package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.OrderListAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Order;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

public class OrderListActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private OrderListActivity fthis;

    private ArrayList<Order> objOrders;
    private RecyclerView rvOrder;
    private RecyclerView.Adapter adapterOrderList;
    private RecyclerView.LayoutManager layoutManager;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;
    private SharedPrefManager sharedPrefManager;
    private TextView tv_noOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getOrdersActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tv_noOrder = (TextView)findViewById(R.id.tv_noOrder);
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(OrderListActivity.this);
        if(!networkDetails.isEmpty()) {
            new GetOrderList().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(OrderListActivity.this), Toast.LENGTH_LONG).show();
        }

    }

    public void displayOrders(){
        rvOrder = (RecyclerView)findViewById(R.id.recycleview_orderlist);
        rvOrder.setVisibility(View.VISIBLE);
        layoutManager = new LinearLayoutManager(this);
        rvOrder.setLayoutManager(layoutManager);
        rvOrder.setHasFixedSize(true);
        adapterOrderList = new OrderListAdapter(objOrders, this, rvOrder);
        rvOrder.setAdapter(adapterOrderList);
    }

    class GetOrderList extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(OrderListActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                json = jsonParser.makeHttpRequestJSON(URLManager.getOrderListURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONArray("data") != null && jsonObject.getJSONArray("data").length() > 0){
                            objOrders = new ArrayList<Order>();
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject obj = jsonObject.getJSONArray("data").getJSONObject(i);
                                Order objOrder = new Order(obj.getString("invoice_id"), obj.getString("created_date"), Integer.parseInt(obj.getString("order_status")), obj.getDouble("grand_total"), obj.getInt("qty"));
                                objOrders.add(objOrder);
                            }
                            displayOrders();
                        }else{
                            tv_noOrder.setVisibility(View.VISIBLE);
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    tv_noOrder.setVisibility(View.VISIBLE);
                }
            }catch(Exception ex){
                tv_noOrder.setVisibility(View.VISIBLE);
                ex.printStackTrace();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

}
