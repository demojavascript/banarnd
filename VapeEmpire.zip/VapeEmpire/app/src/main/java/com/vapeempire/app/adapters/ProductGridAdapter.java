package com.vapeempire.app.adapters;

/**
 * Created by Rahul on 10-01-2016.
 */

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.vapeempire.app.R;
import com.vapeempire.app.activities.ProductDetailActivity;
import com.vapeempire.app.models.Product;
import com.vapeempire.app.utils.URLManager;

import java.util.List;

public class ProductGridAdapter extends BaseAdapter {
    private Context mContext;
    private List<Product> products;

    @Override
    public int getCount() {
        return products.size();
    }

    public ProductGridAdapter(Context c, List<Product> products) {
        mContext = c;
        this.products = products;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View grid;
        final LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            grid = new View(mContext);
            grid = inflater.inflate(R.layout.grid_product_column, null);

            final Product product = products.get(position);
            TextView tvdealname = (TextView) grid.findViewById(R.id.grid_product_name);
            TextView tvproductprice = (TextView) grid.findViewById(R.id.grid_product_price);
            TextView tvSize = (TextView) grid.findViewById(R.id.grid_product_qty);
            ImageView imgdealimg = (ImageView) grid.findViewById(R.id.grid_product_image);
            final CardView cardView = (CardView)grid.findViewById(R.id.cardview_row_product);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, ProductDetailActivity.class);
                    intent.putExtra("productid", product.getProductId());
                    intent.putExtra("brandid", product.getBrandid());
                    intent.putExtra("catid", product.getCatid());
                    intent.putExtra("productname", product.getProductName());
                    mContext.startActivity(intent);
                }
            });
            tvSize.setText(product.getSize()+" ml");
            tvdealname.setText(product.getProductName());
            tvproductprice.setText(mContext.getResources().getString(R.string.rs)+" "+product.getProductPrice());
            Picasso.with(mContext).load(URLManager.getPRODUCTIMGURL(product.getProductIcon())).into(imgdealimg);
        } else {
            grid = (View) convertView;
        }
        return grid;
    }
}