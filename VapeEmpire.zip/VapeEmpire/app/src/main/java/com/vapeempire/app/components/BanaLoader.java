package com.vapeempire.app.components;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;

import com.vapeempire.app.R;

/**
 * Created by Rahul on 01-09-2016.
 */
public class BanaLoader extends ProgressDialog {

    public static ProgressDialog ctor(Context context) {
        BanaLoader dialog = new BanaLoader(context);
        dialog.setIndeterminate(true);
        dialog.setCancelable(false);
        dialog.getWindow().setGravity(Gravity.CENTER);
        return dialog;
    }
    public static ProgressDialog ctor(Context context, int theme) {
        BanaLoader dialog = new BanaLoader(context);
        dialog.setIndeterminate(true);
        dialog.setCancelable(false);
        dialog.getWindow().setGravity(Gravity.CENTER);
        return dialog;
    }
    public BanaLoader(Context context) {
        super(context, R.style.BanaProgressDialogTheme);
    }

    public BanaLoader(Context context, int theme) {
        super(context, theme);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bana_progressdialog);
    }
    @Override
    public void show() {
        super.show();
    }

    @Override
    public void dismiss() {
        super.dismiss();
    }
}
