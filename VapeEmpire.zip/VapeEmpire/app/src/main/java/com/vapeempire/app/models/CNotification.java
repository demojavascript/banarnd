package com.vapeempire.app.models;

/**
 * Created by Rahul on 8/20/17.
 */

public class CNotification {
    private String id;
    private int type;
    private String title;
    private String desc;
    private String bigimg;
    private String smallimg;
    private String date;

    public CNotification(){

    }
    public CNotification(String id, int type, String title, String desc, String bigimg, String smallimg, String date){
        this.id = id;
        this.type = type;
        this.title = title;
        this.desc = desc;
        this.bigimg = bigimg;
        this.smallimg = smallimg;
        this.date = date;
    }
    public void setId(String id){
        this.id = id;
    }
    public void setType(int type){
        this.type = type;
    }
    public void setTitle(String  title){
        this.title = title;
    }
    public void setDesc(String desc){
        this.desc = desc;
    }
    public void setBigimg(String img){
        this.bigimg = img;
    }
    public void setSmallimg(String img){
        this.smallimg = smallimg;
    }
    public void setDate(String date){
        this.date = date;
    }
    public String getId(){
        return this.id;
    }
    public int getType(){
        return this.type;
    }
    public String getTitle(){
        return this.title;
    }
    public String getDesc(){
        return this.desc;
    }
    public String getBigimg(){
        return this.bigimg;
    }
    public String getSmallimg(){
        return this.smallimg;
    }
    public String getDate(){
        return this.date;
    }
}
