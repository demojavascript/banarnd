package com.vapeempire.app.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.vapeempire.app.R;

import static com.vapeempire.app.R.id.radioSizes;

public class ProductDetailActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private ProductDetailActivity fthis;
    private String productid, productname;
    private RadioGroup radioSizes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        radioSizes = (RadioGroup)findViewById(R.id.radioSizes);

        for (int i = 0; i < 3; i++) {
            RadioButton rbn = new RadioButton(this);
            rbn.setId(i+0);
            rbn.setText((i+1)+". quiz");
            rbn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            radioSizes.addView(rbn);
        }

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                productname = intent.getExtras().getString("productname");
                productid = intent.getExtras().getString("productid");
                toolbar.setTitle(productname);
                setSupportActionBar(toolbar);
                getSupportActionBar().setHomeButtonEnabled(true);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }catch(Exception ee){
            ee.printStackTrace();
        }

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
