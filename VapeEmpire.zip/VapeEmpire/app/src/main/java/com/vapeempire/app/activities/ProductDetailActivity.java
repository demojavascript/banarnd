package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.vapeempire.app.R;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Cart;
import com.vapeempire.app.models.Product;
import com.vapeempire.app.models.ProductVariant;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;



public class ProductDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private ProductDetailActivity fthis;
    private String productid, productname, brandId, catdId, pg_vgratio = "50/50";
    private RadioGroup radioSizes;
    private SharedPrefManager sharedPrefManager;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonProductDetail, jsonAvailable, jsonInCart, jsonCartAgain, jsonProductsRelated;
    private NetConnection netConnection;
    private Product dproduct;
    private LinearLayout lout_detail;
    private Button btn_AddToCart;
    private ImageView btnAdd, btnSub;

    private ArrayList<Product> products;
    private ImageView img_src;
    private TextView tv_qty, tv_couponcode, tv_couponamount;
    private int pqty = 0, psize, pingrediens = 0, cartCount;
    private TextView tv_name, tv_size, tv_original_price, tv_intensity,tv_brand, tv_desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        cartCount = sharedPrefManager.getCart_quantity();
        lout_detail = (LinearLayout) findViewById(R.id.lout_detail);
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        radioSizes = (RadioGroup)findViewById(R.id.radioSizes);


        btn_AddToCart = (Button) findViewById(R.id.btn_AddToCart);
        btn_AddToCart.setOnClickListener(this);
        btnAdd = (ImageView) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(this);
        btnSub = (ImageView) findViewById(R.id.btnSub);
        btnSub.setOnClickListener(this);

        tv_qty = (TextView)findViewById(R.id.tv_qty);
        img_src = (ImageView)findViewById(R.id.img_src);
        tv_name = (TextView)findViewById(R.id.tv_name);
        tv_size = (TextView)findViewById(R.id.tv_size);
        tv_original_price = (TextView)findViewById(R.id.tv_original_price);
        tv_desc = (TextView) findViewById(R.id.tv_desc);
        tv_intensity = (TextView)findViewById(R.id.tv_intensity);
        tv_brand = (TextView)findViewById(R.id.tv_brand);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            if (!bundle.isEmpty()) {
                productname = intent.getExtras().getString("productname");
                productid = intent.getExtras().getString("productid");
                brandId = intent.getExtras().getString("brandid");
                catdId = intent.getExtras().getString("catid");
                toolbar.setTitle(productname);
                setSupportActionBar(toolbar);
                getSupportActionBar().setHomeButtonEnabled(true);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);

                netConnection = new NetConnection();
                Map<String, String> networkDetails = netConnection.getConnectionDetails(fthis);
                if(!networkDetails.isEmpty()) {
                    new GettingProductDetail().execute();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                }

            }
        }catch(Exception ee){
            ee.printStackTrace();
        }

    }

    private void dispProductDetail(){
        final Random r = new Random();
        int numm = r.nextInt(3+1);
        lout_detail.setVisibility(View.VISIBLE);
        tv_intensity.setText(pg_vgratio);
        tv_brand.setText(dproduct.getBrandname());
        tv_name.setText(dproduct.getProductName());
        tv_size.setText(dproduct.getSize()+" ml");
        tv_original_price.setText(dproduct.getProductPrice()+"");

        //tv_desc.setHT(dproduct.getProductDesc());
        tv_desc.setText(Html.fromHtml(dproduct.getProductDesc()),TextView.BufferType.SPANNABLE);
        Picasso.with(fthis).load(URLManager.getPRODUCTIMGURL(dproduct.getProductIcon())).into(img_src);

        for (int i = 0; i < dproduct.getProductVariant().size(); i++) {
            RadioButton rbn = new RadioButton(this);
            rbn.setId(i+0);
            if(i==0){
                rbn.setChecked(true);
                psize = dproduct.getProductVariant().get(i).getQty();
                pingrediens = Integer.parseInt(dproduct.getProductVariant().get(i).getSize());
            }
            rbn.setText(dproduct.getProductVariant().get(i).getSize()+" mg");
            rbn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    psize = dproduct.getProductVariant().get(view.getId()).getQty();
                    pingrediens = Integer.parseInt(dproduct.getProductVariant().get(view.getId()).getSize());
                    pqty = 0;
                    tv_qty.setText(pqty+"");
                }
            });
            radioSizes.addView(rbn);
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btn_AddToCart:
                if(pqty == 0){
                    Toast.makeText(getApplicationContext(), ErrorMessages.getProductCartEmpty(fthis), Toast.LENGTH_LONG).show();
                }else{
                    netConnection = new NetConnection();
                    Map<String, String> networkDetails = netConnection.getConnectionDetails(fthis);
                    if(!networkDetails.isEmpty()) {
                        new CheckingAvailable().execute();
                    }else{
                        Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case R.id.btnAdd:
                System.out.print(psize);
                if(pqty < psize){
                    pqty = pqty+1;
                }else {
                    Toast.makeText(getApplicationContext(), ErrorMessages.getProductNoQtyLeft(fthis), Toast.LENGTH_LONG).show();
                }
                tv_qty.setText(pqty+"");
                break;
            case R.id.btnSub:
                if(pqty !=0 ){
                    pqty = pqty-1;
                }
                tv_qty.setText(pqty+"");
                break;
        }
    }

    class GettingProductDetail extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProductDetailActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id", productid);
                objData.put("brand_id", brandId);
                objData.put("category_id", catdId);

                jsonProductDetail = jsonParser.makeHttpRequestJSON(URLManager.getProductDetailURL(), "POST", objData);
                Log.d("jsonProductDetail", objData+"");
                Log.d("jsonProductDetail", jsonProductDetail+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonProductDetail != null){
                    JSONObject jsonObject = jsonProductDetail.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        dproduct = new Product();
                        if(jsonObject.getJSONObject("data") != null){
                            JSONObject product = jsonObject.getJSONObject("data");
                            ArrayList<ProductVariant> variants = new ArrayList<ProductVariant>();
                            for(int j=0; j<product.getJSONArray("variant").length();j++){
                                Log.d("jsonhh ", j+"");
                                JSONObject objvariant = product.getJSONArray("variant").getJSONObject(j);
                                ProductVariant variant = new ProductVariant(objvariant.getString("id"), objvariant.getInt("product_size"), objvariant.getDouble("original_price"), objvariant.getDouble("discounted_price"), objvariant.getString("ingredients"), 0);

                                variants.add(variant);
                            }
                            try{
                                if(product.getString("pgvg_ratio") != null && product.getString("pgvg_ratio").length() != 4){
                                    pg_vgratio = product.getString("pgvg_ratio");
                                }
                            }catch(Exception e){
                                e.printStackTrace();
                            }
                            dproduct = new Product(product.getString("id"), product.getString("name"), product.getString("Image"), product.getDouble("original_price"), product.getString("description"), product.getDouble("discounted_price"), product.getString("sku"), product.getString("meta_key"), product.getString("description"), product.getString("category_id"), product.getString("brand_id"), product.getString("brand_name"), product.getString("category_name"), product.getString("product_size"), variants);
                            dispProductDetail();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    public void showrelatedProducts(){

    }

    class GettingRelatedProducts extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProductDetailActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id", productid);
                objData.put("brand_id", brandId);
                objData.put("category_id", catdId);

                jsonProductsRelated = jsonParser.makeHttpRequestJSON(URLManager.getRelatedProductsURL(), "POST", objData);
                Log.d("jsonProductsRelated", objData+"");
                Log.d("jsonProductsRelated", jsonProductsRelated+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonProductsRelated != null){
                    JSONObject jsonObject = jsonProductsRelated.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        products = new ArrayList<Product>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject product = jsonObject.getJSONArray("data").getJSONObject(i);
                                Product obj = new Product(product.getString("id"), product.getString("name"), product.getString("image"), product.getDouble("original_price"), product.getString("description"), product.getDouble("discounted_price"), product.getString("sku"), product.getString("meta_key"), product.getString("meta_description"), product.getString("category_id"), product.getString("brand_id"), product.getString("brand_name"), product.getString("category_name"), product.getString("product_size"), null);
                                products.add(obj);
                            }
                            showrelatedProducts();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }


    class CheckingAvailable extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(ProductDetailActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id", productid);
                objData.put("ingredients", pingrediens);

                jsonAvailable = jsonParser.makeHttpRequestJSON(URLManager.getProductQtyURL(), "POST", objData);
                Log.d("jsonAvailable", objData+"");
                Log.d("jsonAvailable", jsonAvailable+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {

            try{
                if(jsonAvailable != null){
                    JSONObject jsonObject = jsonAvailable.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONArray("data") != null){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                              JSONObject objData = jsonObject.getJSONArray("data").getJSONObject(i);
                              if(objData.getInt("qty") < pqty){
                                  pDialog.dismiss();
                                  Toast.makeText(getApplicationContext(), "Only "+objData.getInt("qty")+" left.", Toast.LENGTH_SHORT).show();
                              }else{
                                  new AddInCart().execute();
                              }
                            }
                        }else{
                            pDialog.dismiss();
                        }
                    }else{
                        pDialog.dismiss();
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    pDialog.dismiss();
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                pDialog.dismiss();
                ex.printStackTrace();
            }
        }
    }


    class AddInCart extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("product_id", productid);
                objData.put("ingredients", pingrediens);
                objData.put("qty", pqty);

                jsonInCart = jsonParser.makeHttpRequestJSON(URLManager.getAddInCartURL(), "POST", objData);
                Log.d("jsonInCart", objData+"");
                Log.d("jsonInCart", jsonInCart+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonInCart != null){
                    JSONObject jsonObject = jsonInCart.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        Toast.makeText(getApplicationContext(), ErrorMessages.getProductAddedMsg(fthis), Toast.LENGTH_SHORT).show();
                        pqty = 0;
                        new GetMiniCartAgain().execute();
                        tv_qty.setText(pqty+"");
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    class GetMiniCartAgain extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                jsonCartAgain = jsonParser.makeHttpRequestJSON(URLManager.getMiniCartURL(), "POST", objData);
                Log.d("jsonCartAgain", objData+"");
                Log.d("jsonCartAgain", jsonCartAgain+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonCartAgain != null){
                    JSONObject jsonObject = jsonCartAgain.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        if(jsonObject.getJSONArray("data") != null && jsonObject.getJSONArray("data").length() > 0){
                            int rr = 0;
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                rr++;
                            }
                            sharedPrefManager.setCart_quantity(rr);
                            cartCount = sharedPrefManager.getCart_quantity();
                            invalidateOptionsMenu();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.findItem(R.id.cartBadge);
        menuItem.setIcon(Helper.buildCounterDrawable(cartCount, R.drawable.ic_cart_w, this));
        return true;
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        cartCount = sharedPrefManager.getCart_quantity();
        invalidateOptionsMenu();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.cartBadge) {
            if(cartCount != 0){
                Intent intent = new Intent(ProductDetailActivity.this, CartActivity.class);
                startActivity(intent);
            }
        }else if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
