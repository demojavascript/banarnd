package com.vapeempire.app.utils;

import android.content.Context;
import android.content.res.Resources;

import com.vapeempire.app.R;

/**
 * Created by Rahul on 6/9/17.
 */

public class ErrorMessages {

    public static String getNoInternet(Context ctx){
        return getResources(ctx).getString(R.string.noConnection);
    }
    public static String getEmailEmpty(Context ctx){
        return getResources(ctx).getString(R.string.login_emailisempty);
    }
    public static String getEmailIncorrect(Context ctx){
        return getResources(ctx).getString(R.string.login_emailisincorrect);
    }
    public static String getPwdEmpty(Context ctx){
        return getResources(ctx).getString(R.string.login_pwdempty);
    }
    public static String getPwdLength(Context ctx){
        return getResources(ctx).getString(R.string.login_pwdlength);
    }
    public static String getNameEmpty(Context ctx){
        return getResources(ctx).getString(R.string.login_nameempty);
    }
    public static String getNameLength(Context ctx){
        return getResources(ctx).getString(R.string.login_nameLength);
    }
    public static String getShareAppTitle(Context ctx){
        return getResources(ctx).getString(R.string.shareAppTitle);
    }
    public static String getCommonErrorMsg(Context ctx){
        return getResources(ctx).getString(R.string.common_error_msg);
    }
    public static String getFBMsgCancel(Context ctx){
        return getResources(ctx).getString(R.string.login_fb_login_cancelled);
    }
    public static String getFBMsgError(Context ctx){
        return getResources(ctx).getString(R.string.login_fb_login_error);
    }
    public static String getAddAddressMsg(Context ctx){
        return getResources(ctx).getString(R.string.addAddress_added);
    }
    public static String getEmptyFName(Context ctx){
        return getResources(ctx).getString(R.string.address_emptyfn);
    }
    public static String getEmptyLName(Context ctx){
        return getResources(ctx).getString(R.string.address_emptyln);
    }
    public static String getEmptyAddress(Context ctx){
        return getResources(ctx).getString(R.string.address_emptyaddress);
    }
    public static String getEmptyCity(Context ctx){
        return getResources(ctx).getString(R.string.address_emptycity);
    }
    public static String getEmptyState(Context ctx){
        return getResources(ctx).getString(R.string.address_emptystate);
    }
    public static String getEmptyPincode(Context ctx){
        return getResources(ctx).getString(R.string.address_emptypincode);
    }
    public static String getInvalidPincode(Context ctx){
        return getResources(ctx).getString(R.string.address_invalidpincode);
    }
    public static String getEmptyEmail(Context ctx){
        return getResources(ctx).getString(R.string.address_emptyemail);
    }
    public static String getInvalidEmail(Context ctx){
        return getResources(ctx).getString(R.string.address_invalidemail);
    }
    public static String getInvalidMobileNum(Context ctx){
        return getResources(ctx).getString(R.string.address_invalidmobile);
    }
    public static String getAddressDeleteConfirm(Context ctx){
        return getResources(ctx).getString(R.string.address_delete_confirm_msg);
    }
    public static String getAddressDeleteYes(Context ctx){
        return getResources(ctx).getString(R.string.address_delete_yes);
    }
    public static String getAddressDeleteNo(Context ctx){
        return getResources(ctx).getString(R.string.address_delete_no);
    }
    public static String getCouponAlreadyApplied(Context ctx){
        return getResources(ctx).getString(R.string.checkout_coupon_already_applied);
    }
    public static String getEmptyCouponCode(Context ctx){
        return getResources(ctx).getString(R.string.checkout_enter_couponcode);
    }
    public static String getAddressUpdatedMsg(Context ctx){
        return getResources(ctx).getString(R.string.address_updated_msg);
    }
    public static String getNoOrder(Context ctx){
        return getResources(ctx).getString(R.string.order_empty_msg);
    }
    public static String getOrderPlacedMsg(Context ctx){
        return getResources(ctx).getString(R.string.order_place_success_msg);
    }
    public static String getProductAddedMsg(Context ctx){
        return getResources(ctx).getString(R.string.product_added_tocart);
    }
    public static String getProductNoQtyLeft(Context ctx){
        return getResources(ctx).getString(R.string.product_no_more_product_left);
    }
    public static String getProductCartEmpty(Context ctx){
        return getResources(ctx).getString(R.string.product_cart_empty);
    }
    //shareAppTitle
    private static Resources getResources(Context ctx){
        return ctx.getResources();
    }
}
