package com.vapeempire.app.utils;

import android.content.Context;
import android.content.res.Resources;

import com.vapeempire.app.R;

/**
 * Created by Rahul on 6/9/17.
 */

public class ErrorMessages {

    public static String getNoInternet(Context ctx){
        return getResources(ctx).getString(R.string.noConnection);
    }
    public static String getShareAppTitle(Context ctx){
        return getResources(ctx).getString(R.string.shareAppTitle);
    }
    //shareAppTitle
    private static Resources getResources(Context ctx){
        return ctx.getResources();
    }
}
