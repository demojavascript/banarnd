package com.vapeempire.app.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;


import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.vapeempire.app.R;
import com.vapeempire.app.activities.MainActivity;
import com.vapeempire.app.db.DatabaseHandler;
import com.vapeempire.app.models.CNotification;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Rahul on 01-07-2016.
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private DatabaseHandler db;
    private CNotification objNotify = null;
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        //System.out.print(remoteMessage);
        //Log.d("ndata", remoteMessage+"");
        //sendNotification(remoteMessage.getData().get("title"), remoteMessage.getData().get("body"), 1,"", "");
    }

    private void sendNotification(String title, String body, int type, String simg, String bimg) {

        objNotify = new CNotification();
        objNotify.setTitle(title);
        objNotify.setDesc(body);
        objNotify.setType(type);
        objNotify.setDate(System.currentTimeMillis()+"");
        objNotify.setBigimg(bimg);
        objNotify.setSmallimg(simg);
        //db.insertNotification(objNotify);
        //db.deleteAfter10();


        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT);

        if(bimg != null && bimg.length()>0) {
            Bitmap bmp = getBitmapFromURL(bimg);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setSmallIcon(R.drawable.ic_profile)
                    .setLargeIcon(bmp)
                    .setWhen(System.currentTimeMillis())
                    .setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(body))
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(0, notificationBuilder.build());
        }else{
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setSmallIcon(R.drawable.ic_profile)
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            notificationManager.notify(0, notificationBuilder.build());
        }

    }
    public static Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}