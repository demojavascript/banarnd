package com.vapeempire.app.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

import com.vapeempire.app.R;
import com.vapeempire.app.models.SharedPrefManager;

public class SplashActivity extends Activity implements View.OnClickListener  {

    private SharedPrefManager sharedPrefManager;
    private SplashActivity fthis;
    private LinearLayout lout_first, lout_default;
    private Button splashBtnYes, splashBtnNo;
    private static int SPLASH_TIME_OUT = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        fthis = this;

        lout_first = (LinearLayout)findViewById(R.id.lout_first);
        lout_default = (LinearLayout)findViewById(R.id.lout_default);
        splashBtnYes = (Button)findViewById(R.id.splashBtnYes);
        splashBtnYes.setOnClickListener(this);
        splashBtnNo = (Button)findViewById(R.id.splashBtnNo);
        splashBtnNo.setOnClickListener(this);

        sharedPrefManager = new SharedPrefManager(fthis);
        if(sharedPrefManager.getUserAgree().equals("1")){
            lout_default.setVisibility(View.VISIBLE);
            startGo();
        }else{
            lout_first.setVisibility(View.VISIBLE);
        }
    }
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.splashBtnYes:
                sharedPrefManager.setUserAgree("1");
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                break;
            case R.id.splashBtnNo:

                break;
        }
        finish();
    }
    public void startGo(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent;
                if(sharedPrefManager.getIsLogin()){
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                }else {
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
                startActivity(intent);
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
