package com.vapeempire.app.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;

import com.vapeempire.app.R;
import com.vapeempire.app.adapters.NotificationAdapter;
import com.vapeempire.app.db.DatabaseHandler;
import com.vapeempire.app.models.CNotification;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ActivityTitle;

import java.util.ArrayList;

public class NotificationsActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private SharedPrefManager sharedPrefManager;
    private NotificationsActivity fthis;

    private ArrayList<CNotification> notificationsList;
    private RecyclerView rv_notificationlist;
    private RecyclerView.Adapter adapterNotificationList;
    private RecyclerView.LayoutManager layoutManager;
    private DatabaseHandler db;
    private String activity_source = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle(ActivityTitle.getNotificationActivityTitle(fthis));
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db = new DatabaseHandler(this);
        db.syncNotification();

        notificationsList = new ArrayList<CNotification>();
        notificationsList = db.getAllNotification();

        try {
            Intent intent = getIntent();
            Bundle bundle = intent.getExtras();
            if (!bundle.isEmpty()) {
                activity_source = intent.getExtras().getString("source", "");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        displayData();
    }

    public void displayData(){
        rv_notificationlist = (RecyclerView)findViewById(R.id.rv_notificationlist);
        layoutManager = new LinearLayoutManager(this);
        rv_notificationlist.setLayoutManager(layoutManager);
        rv_notificationlist.setHasFixedSize(true);
        adapterNotificationList = new NotificationAdapter(notificationsList, this, rv_notificationlist);
        rv_notificationlist.setAdapter(adapterNotificationList);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(activity_source.length() > 0){
            Intent intent  = new Intent(NotificationsActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }else{
            if(id == android.R.id.home){
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        if(activity_source.length() > 0){
            super.onBackPressed();
            finish();
        }else {
            Intent intent  = new Intent(NotificationsActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }
}
