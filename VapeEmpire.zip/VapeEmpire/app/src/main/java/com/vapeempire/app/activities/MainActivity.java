package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.github.juanlabrador.badgecounter.BadgeCounter;
import com.squareup.picasso.Picasso;
import com.vapeempire.app.Fragment.NavigationDrawerFragment;
import com.vapeempire.app.R;
import com.vapeempire.app.adapters.CategoryGridAdapter;
import com.vapeempire.app.adapters.HomeSliderAdapter;
import com.vapeempire.app.adapters.SidebarAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.gridviews.CategoryGridView;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Cart;
import com.vapeempire.app.models.Category;
import com.vapeempire.app.models.Product;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.models.Slider;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.Helper;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    private Toolbar toolbar;
    private NavigationDrawerFragment drawerFragment;
    private ImageView user_profile_pic;
    private ProgressDialog banaLoader = null;
    private ListView listviewsidebar;
    private String[] menuOptions;
    private SidebarAdapter sidebarAdapter;
    private MainActivity fthis;
    private DrawerLayout drawerLayout;
    private SharedPrefManager sharedPrefManager;
    private TextView tv_username, tv_emailid;

    private LinearLayout lout_sliders, lout_cats;

    private List<Category> categories;
    private CategoryGridAdapter categoryGridAdapter;
    private CategoryGridView categoryGridView;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject jsonCategory, jsonProducts;
    private NetConnection netConnection;
    private int slideIndex = 0, cartCount = 0;

    private HomeSliderAdapter homeSliderAdapter;
    private RecyclerView rv_home_fproduct;
    private ArrayList<String> horizontalList;
    private ArrayList<Product> products;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);

        drawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), toolbar);

        Resources objres = getResources();
        menuOptions = objres.getStringArray(R.array.sidebarOptions);
        listviewsidebar = (ListView) findViewById(R.id.sidebar_menu);
        sidebarAdapter = new SidebarAdapter(this, menuOptions);
        listviewsidebar.setAdapter(sidebarAdapter);
        listviewsidebar.setOnItemClickListener(this);

        user_profile_pic = (ImageView)findViewById(R.id.user_profile_pic);
        lout_cats = (LinearLayout)findViewById(R.id.lout_cats);
        tv_emailid = (TextView)findViewById(R.id.tv_emailid);
        tv_username = (TextView)findViewById(R.id.tv_username);


        if(sharedPrefManager.getUname().length() > 0){
            tv_username.setText(sharedPrefManager.getUname());
        }
        if(sharedPrefManager.getEmail().length() > 0){
            tv_emailid.setText(sharedPrefManager.getEmail());
        }

        if(sharedPrefManager.getUpicurl() != null && sharedPrefManager.getUpicurl().length() > 0){
            Picasso.with(fthis).load(sharedPrefManager.getUpicurl()).into(user_profile_pic);
        }else if(sharedPrefManager.getUgender() > 0){
            if(sharedPrefManager.getUgender() == 1){
                user_profile_pic.setImageResource(R.drawable.ic_user_m);
            }else if(sharedPrefManager.getUgender() == 2){
                user_profile_pic.setImageResource(R.drawable.ic_user_f);
            }
        }
        cartCount = sharedPrefManager.getCart_quantity();
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(MainActivity.this);
        if(!networkDetails.isEmpty()) {
            new GettingCategory().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(MainActivity.this), Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.findItem(R.id.cartBadge);
        menuItem.setIcon(Helper.buildCounterDrawable(cartCount, R.drawable.ic_cart_w, this));
        return true;
    }
    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
        cartCount = sharedPrefManager.getCart_quantity();
        invalidateOptionsMenu();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.cartBadge) {
            if(cartCount != 0){
                Intent intent = new Intent(MainActivity.this, CartActivity.class);
                startActivity(intent);
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void showSlider2(){
        lout_sliders = (LinearLayout)findViewById(R.id.lout_sliders);
        lout_sliders.setVisibility(View.VISIBLE);
        rv_home_fproduct = (RecyclerView)findViewById(R.id.rv_home_fproduct);
        homeSliderAdapter = new HomeSliderAdapter(products, fthis, rv_home_fproduct);
        LinearLayoutManager horizontalLayoutManagaer = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        rv_home_fproduct.setLayoutManager(horizontalLayoutManagaer);
        rv_home_fproduct.setAdapter(homeSliderAdapter);

    }

    private void dispCat(){
        if(categories.size() > 0){
            lout_cats.setVisibility(View.VISIBLE);
        }
        categoryGridAdapter = new CategoryGridAdapter(MainActivity.this, categories);
        categoryGridView = (CategoryGridView) findViewById(R.id.gridCategory);
        categoryGridView.setNumColumns(1);
        categoryGridView.setAdapter(categoryGridAdapter);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){

        }
    }


    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(MainActivity.this);
        switch(position){
            case 0:
                Intent profileIntent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case 1:
                Intent orderIntent = new Intent(MainActivity.this, OrderListActivity.class);
                startActivity(orderIntent);
                break;
            case 2:
                Intent addressIntent = new Intent(MainActivity.this, AddressActivity.class);
                addressIntent.putExtra("address_type", 1);
                startActivity(addressIntent);
                break;
            case 3:
                Intent billingIntent = new Intent(MainActivity.this, AddressActivity.class);
                billingIntent.putExtra("address_type", 2);
                startActivity(billingIntent);
                break;
            case 4:
                Intent notificationIntent = new Intent(MainActivity.this, NotificationsActivity.class);
                notificationIntent.putExtra("source", "home");
                startActivity(notificationIntent);
                break;
            case 5:
                if(!networkDetails.isEmpty()) {
                    shareApp();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                }
                break;
            case 6:
                callUs();
                break;
            case 7:
                if(!networkDetails.isEmpty()) {
                    rateus();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                }
                break;
            case 8:
                Intent contentIntent = new Intent(MainActivity.this, ContentActivity.class);
                startActivity(contentIntent);
                break;
            case 9:

                break;
        }
    }
    public void rateus(){
        Uri uri = Uri.parse(URLManager.getPlayStoreMarketURL());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            fthis.startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            fthis.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(URLManager.getPlayStoreURL())));
        }
    }
    public void shareApp(){
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.app_google_play_url));
        startActivity(Intent.createChooser(shareIntent, ErrorMessages.getShareAppTitle(fthis)));
    }
    public void callUs(){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+getResources().getString(R.string.customer_care_no)));
        startActivity(intent);
    }

    class GettingProducts extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());

                jsonProducts = jsonParser.makeHttpRequestJSON(URLManager.getTopProductURL(), "POST", objData);
                Log.d("jsonProducts", objData+"");
                Log.d("jsonProducts", jsonProducts+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(jsonProducts != null){
                    JSONObject jsonObject = jsonProducts.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        products = new ArrayList<Product>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject product = jsonObject.getJSONArray("data").getJSONObject(i);
                                Product obj = new Product(product.getString("id"), product.getString("name"), product.getString("image"), product.getDouble("original_price"), product.getString("description"), product.getDouble("discounted_price"), product.getString("sku"), product.getString("meta_key"), product.getString("meta_description"), product.getString("category_id"), product.getString("brand_id"), product.getString("brand_name"), product.getString("category_name"), product.getString("product_size"), null);
                                products.add(obj);
                            }
                            showSlider2();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }



    class GettingCategory extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(MainActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());
                objData.put("home_status", 1);

                jsonCategory = jsonParser.makeHttpRequestJSON(URLManager.getCategoryURL(), "POST", objData);
                Log.d("jsonCategory", objData+"");
                Log.d("jsonCategory", jsonCategory+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            new GettingProducts().execute();
            try{
                if(jsonCategory != null){
                    JSONObject jsonObject = jsonCategory.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        categories = new ArrayList<Category>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject category = jsonObject.getJSONArray("data").getJSONObject(i);
                                Category cat = new Category(category.getString("id"), category.getString("name"), category.getString("image"), category.getInt("total_product"), category.getInt("total_child"), category.getInt("total_brand"), category.getString("description"));
                                categories.add(cat);
                            }
                            dispCat();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    if(Helper.isShowCommonErrorToast()) {
                        Toast.makeText(getApplicationContext(), ErrorMessages.getCommonErrorMsg(fthis), Toast.LENGTH_SHORT).show();
                    }
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }



}
