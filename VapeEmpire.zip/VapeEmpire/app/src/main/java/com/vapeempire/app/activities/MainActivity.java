package com.vapeempire.app.activities;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.vapeempire.app.Fragment.NavigationDrawerFragment;
import com.vapeempire.app.R;
import com.vapeempire.app.adapters.CategoryGridAdapter;
import com.vapeempire.app.adapters.SidebarAdapter;
import com.vapeempire.app.components.BanaLoader;
import com.vapeempire.app.gridviews.CategoryGridView;
import com.vapeempire.app.libs.JSONParser;
import com.vapeempire.app.models.Category;
import com.vapeempire.app.models.SharedPrefManager;
import com.vapeempire.app.utils.ErrorMessages;
import com.vapeempire.app.utils.NetConnection;
import com.vapeempire.app.utils.URLManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener  {

    private Toolbar toolbar;
    private NavigationDrawerFragment drawerFragment;
    private ImageView user_profile_pic;
    private ProgressDialog banaLoader = null;
    private ListView listviewsidebar;
    private String[] menuOptions;
    private SidebarAdapter sidebarAdapter;
    private MainActivity fthis;
    private DrawerLayout drawerLayout;
    private SharedPrefManager sharedPrefManager;
    private TextView tv_username, tv_emailid;

    private List<Category> categories;
    private CategoryGridAdapter categoryGridAdapter;
    private CategoryGridView categoryGridView;

    private ProgressDialog pDialog;
    private JSONParser jsonParser = new JSONParser();
    private JSONObject json;
    private NetConnection netConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPrefManager = new SharedPrefManager(this);
        fthis = this;
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);

        drawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), toolbar);

        Resources objres = getResources();
        menuOptions = objres.getStringArray(R.array.sidebarOptions);
        listviewsidebar = (ListView) findViewById(R.id.sidebar_menu);
        sidebarAdapter = new SidebarAdapter(this, menuOptions);
        listviewsidebar.setAdapter(sidebarAdapter);
        listviewsidebar.setOnItemClickListener(this);

        user_profile_pic = (ImageView)findViewById(R.id.user_profile_pic);
        tv_emailid = (TextView)findViewById(R.id.tv_emailid);
        tv_username = (TextView)findViewById(R.id.tv_username);

        if(sharedPrefManager.getUname().length() > 0){
            tv_username.setText(sharedPrefManager.getUname());
        }
        if(sharedPrefManager.getEmail().length() > 0){
            tv_emailid.setText(sharedPrefManager.getEmail());
        }

        if(sharedPrefManager.getUpicurl() != null && sharedPrefManager.getUpicurl().length() > 0){
            Picasso.with(fthis).load(sharedPrefManager.getUpicurl()).into(user_profile_pic);
        }else if(sharedPrefManager.getUgender() > 0){
            if(sharedPrefManager.getUgender() == 1){
                user_profile_pic.setImageResource(R.drawable.ic_user_m);
            }else if(sharedPrefManager.getUgender() == 2){
                user_profile_pic.setImageResource(R.drawable.ic_user_f);
            }
        }

        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(MainActivity.this);
        if(!networkDetails.isEmpty()) {
            new GettingCategory().execute();
        }else{
            Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(MainActivity.this), Toast.LENGTH_LONG).show();
        }

    }

    private void dispCat(){
        categoryGridAdapter = new CategoryGridAdapter(MainActivity.this, categories);
        categoryGridView = (CategoryGridView) findViewById(R.id.gridCategory);
        categoryGridView.setNumColumns(2);
        categoryGridView.setAdapter(categoryGridAdapter);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){

        }
    }

    @Override
    public void onResume() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onResume();
    }

    @Override
    public void onStart() {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onStart();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        netConnection = new NetConnection();
        Map<String, String> networkDetails = netConnection.getConnectionDetails(MainActivity.this);
        switch(position){
            case 0:
                Intent profileIntent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
                break;
            case 1:
                Intent orderIntent = new Intent(MainActivity.this, OrderListActivity.class);
                startActivity(orderIntent);
                break;
            case 2:
                Intent addressIntent = new Intent(MainActivity.this, AddressActivity.class);
                startActivity(addressIntent);
                break;
            case 3:
                Intent notificationIntent = new Intent(MainActivity.this, BillingDetailActivity.class);
                startActivity(notificationIntent);
                break;
            case 4:
                Intent billingIntent = new Intent(MainActivity.this, NotificationsActivity.class);
                startActivity(billingIntent);
                break;
            case 5:
                if(!networkDetails.isEmpty()) {
                    shareApp();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                }
                break;
            case 6:
                callUs();
                break;
            case 7:
                if(!networkDetails.isEmpty()) {
                    rateus();
                }else{
                    Toast.makeText(getApplicationContext(), ErrorMessages.getNoInternet(fthis), Toast.LENGTH_LONG).show();
                }
                break;
            case 8:
                Intent contentIntent = new Intent(MainActivity.this, ContentActivity.class);
                startActivity(contentIntent);
                break;
            case 9:

                break;
        }
    }
    public void rateus(){
        Uri uri = Uri.parse(URLManager.getPlayStoreMarketURL());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            fthis.startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            fthis.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(URLManager.getPlayStoreURL())));
        }
    }
    public void shareApp(){
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.app_google_play_url));
        startActivity(Intent.createChooser(shareIntent, ErrorMessages.getShareAppTitle(fthis)));
    }
    public void callUs(){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+getResources().getString(R.string.customer_care_no)));
        startActivity(intent);
    }

    class GettingCategory extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = BanaLoader.ctor(MainActivity.this);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... args) {
            JSONObject objData = new JSONObject();
            try{
                objData.put("device_id", sharedPrefManager.getDeviceID());

                json = jsonParser.makeHttpRequestJSON(URLManager.getCategoryURL(), "POST", objData);
                Log.d("jdon", objData+"");
                Log.d("json", json+"");
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String responseData) {
            pDialog.dismiss();
            try{
                if(json != null){
                    JSONObject jsonObject = json.getJSONObject("response");
                    if(jsonObject.getInt("status") == 1){
                        categories = new ArrayList<Category>();
                        if(jsonObject.getJSONArray("data").length() > 0){
                            for(int i=0;i<jsonObject.getJSONArray("data").length();i++){
                                JSONObject category = jsonObject.getJSONArray("data").getJSONObject(i);
                                Category cat = new Category(category.getString("id"), category.getString("name"), category.getString("image"), category.getInt("total_product"), category.getInt("total_child"), category.getInt("total_brand"), category.getString("description"));
                                categories.add(cat);
                            }
                            dispCat();
                        }
                    }else{
                        Toast.makeText(getApplicationContext(), jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "some error occurred. Try again.", Toast.LENGTH_SHORT).show();
                }
            }catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

}
